﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class Operaciones
    {
        public Operaciones()
        {
            //Atributos = son las variables donde se almacena la informacion
            double productoA, productoB, sumandoA, sumandoB, divisor, dividendo, minuendo, sustraendo;
            double resultadoMultiplicacion, resultadoDivision, resultadoSuma, resultadoResta;

            //Metodos = son las acicones que puede realizar el objeto de la clase

            //Metodos Set = para asignar valores

            public void setProducto(double prodA, double prodB)
            {
                productoA = prodA;
                productoB = prodB;
            }

            //Metodo Get = para devolver valores

            public double getTotalMultiplicacion()
            {
                return resultadoMultiplicacion;
            }

            public void multiplicar()
            {
                resultadoMultiplicacion = productoA * productoB;
            }
        }
    }

}