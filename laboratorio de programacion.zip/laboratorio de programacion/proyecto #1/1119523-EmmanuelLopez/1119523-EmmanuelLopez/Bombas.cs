﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1119523_EmmanuelLopez
{
    public class Bomba
    {
        private double CombustibleDespachado;
        private double DineroVentas;


        public double GetCombustibleDespachadoGalones() { return CombustibleDespachado; }
        public double GetDineroVentas() { return DineroVentas; }

        public void DespacharCombustibleGalones(TipoDeGasolina tipo, double galones)
        {
            CombustibleDespachado += galones;
            DineroVentas += tipo.GetPrecio() * galones;
        }
    }
}