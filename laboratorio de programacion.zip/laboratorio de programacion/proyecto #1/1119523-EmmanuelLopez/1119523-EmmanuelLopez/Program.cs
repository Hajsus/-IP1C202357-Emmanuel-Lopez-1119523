﻿
using _1119523_EmmanuelLopez;
using System.ComponentModel.Design;
using System.Linq.Expressions;

public static class Program
{
    
    public class Programa
    {
        

        private static Menu objetoVentas = new Menu();
        public static void Main(string[] args)
        {
            // Inicio de Progrma
            MostrarMenuPrincipal();
        }

        public static void MostrarMenuPrincipal()
        {
            bool salir = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Bienvenidos a Gasolinera OVERFLOW");
                Console.WriteLine(" ");
                Console.WriteLine("Seleccione de qué forma desea ingresar");
                Console.WriteLine(" ");
                Console.WriteLine("1. CLIENTE");
                Console.WriteLine("2. ADMINISTRADOR");
                Console.WriteLine("0. REGRESAR");

                Console.Write("Seleccione una opcion: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Console.WriteLine("Es un gusto tenerlo como cliente");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Pedido por galones");
                        Console.WriteLine("2. Pedido por quetzales ");
                        Console.WriteLine(" ");
                        Console.WriteLine("Por favor ingrese la acción que desea realizar: ");
                        int _respuesta = int.Parse(Console.ReadLine());

                        if (_respuesta == 1)
                        {

                        }

                        else
                        {

                        }

                        MostrarMenuVentas();
                        break;
                    case "2":
                        Console.WriteLine("Bienvenido Administrador");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Cambio del valor de venta");
                        Console.WriteLine("2. Reabastecimiento");
                        Console.WriteLine("3. Información de ventas ");
                        Console.WriteLine(" ");
                        Console.WriteLine("Por favor ingrese la acción que desea realizar: ");
                        int _respuesta2 = int.Parse(Console.ReadLine());

                        if (_respuesta2 == 1)
                        {

            

            static void CostosDeGasolina()
            {
                                double
            _PrecioDiesel = 31.11,
            _PrecioRegular = 31.84,
            _PrecioSuper = 33.33,
            _PrecioPremium = 34.10;
                                Console.WriteLine("\nPrecio por galon:");
                Console.WriteLine("* Diesel = " + "Q. " + _PrecioDiesel);
                Console.WriteLine("* Regular = " + "Q. " + _PrecioRegular);
                Console.WriteLine("* Super = " + "Q. " + _PrecioSuper);
                Console.WriteLine("* Premium = " + "Q. " + _PrecioPremium);

            }

            void SINO()
            {

                string _Continuar = Console.ReadLine();
                bool _Reiniciar = false;

                if (_Continuar == "Y".ToLower())
                {
                    do
                    {

                        Console.WriteLine("\nDetermina los nuevos valores de cada combustible:");
                        Console.WriteLine("* Diesel: "); double _PrecioDiesel2 = double.Parse(Console.ReadLine());
                        Console.WriteLine("* Regular: "); double _PrecioRegular2 = double.Parse(Console.ReadLine());
                        Console.WriteLine("* Super: "); double _PrecioSuper2 = double.Parse(Console.ReadLine());
                        Console.WriteLine("* Premium: "); double _PrecioPremium2 = double.Parse(Console.ReadLine());

                        if (_PrecioDiesel2 < _PrecioDiesel)
                        {

                            _Reiniciar = true;
                            Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                            Console.WriteLine("Porfavor reingrese los datos.");

                        }
                        else if (_PrecioRegular2 < _PrecioRegular)
                        {

                            _Reiniciar = true;
                            Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                            Console.WriteLine("Porfavor reingrese los datos.");

                        }
                        else if (_PrecioSuper2 < _PrecioSuper)
                        {

                            _Reiniciar = true;
                            Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                            Console.WriteLine("Porfavor reingrese los datos.");

                        }
                        else if (_PrecioPremium2 < _PrecioPremium)
                        {

                            _Reiniciar = true;
                            Console.WriteLine("Este precio generará pérdidas a la gasolinera.");
                            Console.WriteLine("Porfavor reingrese los datos.");

                        }
                        else
                        {

                            _Reiniciar = false;
                            Console.WriteLine("\nCostos actuales:");
                            Console.WriteLine("* Diesel = " + "Q. " + _PrecioDiesel);
                            Console.WriteLine("* Regular = " + "Q. " + _PrecioRegular);
                            Console.WriteLine("* Super = " + "Q. " + _PrecioSuper);
                            Console.WriteLine("* Premium = " + "Q. " + _PrecioPremium);

                        }

                    } while (_Reiniciar == true);

                }
                else
                {

                    // Cierra la clase
                    Console.WriteLine("ENTENDIDO");

                }
            }

                        if (_respuesta2 == 2)
                        {

                        }

                        if (_respuesta2 == 3)
                        {

                        }

                        objetoVentas.InformacionDeVentas();
                        break;

                    default:
                        objetoVentas.Adios();
                        salir = true;
                        break;
                }

            } while (!salir);
        }

        public static void MostrarMenuVentas()
        {
            bool salir = false;
            do
            {
                Console.Clear();
                Console.WriteLine("MENU PRINCIPAL");
                Console.WriteLine("1. VETA AL CLIENTE");
                Console.WriteLine("2. REABASTECIMIENTO DE ALMACENES");
                Console.WriteLine("0. REGRESAR");

                Console.Write("Seleccione una opcion: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        objetoVentas.VentaAlCliente();
                        break;
                    case "2":
                        Console.WriteLine("A elegido Reabastecimiento de los almacenes.");
                        string _Usuario;
                        string _Contraseña;
                        bool _Continuar = false;
                        try
                        {
                            do
                            {

                                Console.WriteLine("Porfavor ingrese su usuario y contraseña. ");
                                Console.WriteLine("Porfavor ingrese el usuario.");
                                _Usuario = Console.ReadLine();
                                Console.WriteLine("Porfavor ingrese la contraseña.");
                                _Contraseña = Console.ReadLine();

                                if (_Usuario == "Overflow1460" && _Contraseña == "23641122")
                                {

                                    _Continuar = true;
                                    Console.WriteLine("Bienvenido " + _Usuario);


                                }

                                else
                                {

                                    _Continuar = false;
                                    Console.WriteLine("Usuario y/o contraseña incorrecta \n");

                                }

                            }

                            while (_Continuar == false);

                        }

                        catch
                        {

                            Console.WriteLine("Ha ocurrido un error. Vuelva a intentarlo");

                        }
                        break;
                    default:
                        salir = true;
                        break;
                }

            } while (!salir);
        }
    }
}