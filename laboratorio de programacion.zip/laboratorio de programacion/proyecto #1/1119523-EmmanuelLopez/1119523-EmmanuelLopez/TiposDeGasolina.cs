﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1119523_EmmanuelLopez
{
    public class TipoDeGasolina
    {

        public string Nombre;
        private double Precio;

        public double GetPrecio()
        {
            return Precio;

        }

        public bool SetPrecio(double nuevoPrecio)
        {

            if (Precio < nuevoPrecio)
            {
                Precio = nuevoPrecio;
                return true;
            }
            return false;
        }
    }


}



