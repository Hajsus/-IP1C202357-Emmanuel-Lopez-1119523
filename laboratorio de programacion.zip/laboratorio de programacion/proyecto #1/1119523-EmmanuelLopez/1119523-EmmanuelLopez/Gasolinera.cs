﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1119523_EmmanuelLopez
{
    public class Gasolinera
    {
        private Almacen _depositoDiesel = new Almacen();
        private Almacen _depositoRegular = new Almacen();
        private Almacen _depositoSuper = new Almacen();
        private Almacen _depositoPremium = new Almacen();
        private Bomba _bomba1 = new Bomba();
        private Bomba _bomba2 = new Bomba();
        private Bomba _bomba3 = new Bomba();
        private Bomba _bomba4 = new Bomba();
        private Bomba _bomba5 = new Bomba();

        public Gasolinera()
        {
            double _DepoDiesel = 500;
            double _DepoRegular = 500;
            double _DepoSuper = 500;
            double _DepoPremium = 500;

           void GalonesDisponibles()
            {

                Console.WriteLine("\nGalones disponibles:");
                Console.WriteLine("* Diesel = " + _DepoDiesel + "/2500 galones");
                Console.WriteLine("* Regular = " + _DepoRegular + "/2500 galones");
                Console.WriteLine("* Super = " + _DepoSuper + "/2500 galones");
                Console.WriteLine("* Premium = " + _DepoPremium + "/2500 galones");

            }


        }







        public void RecargarCombustible()
        {
            string _Continuar = Console.ReadLine();

            double _DepoDiesel = 500;
            double _DepoRegular = 500;
            double _DepoSuper = 500;
            double _DepoPremium = 500;

            double _PrecioDiesel = 15;
            double _PrecioRegular = 15;
            double _PrecioSuper = 18;
            double _PrecioPremium = 20;

           void SINO()
            {
                if (_Continuar == "Y".ToLower())
                {



                    Console.WriteLine("\nPrecio por galon:");
                    Console.WriteLine("* Diesel = " + "Q. " + _PrecioDiesel);
                    Console.WriteLine("* Regular = " + "Q. " + _PrecioRegular);
                    Console.WriteLine("* Super = " + "Q. " + _PrecioSuper);
                    Console.WriteLine("* Premium = " + "Q. " + _PrecioPremium);
                    bool _ContinuarPago1 = true;
                    bool _ContinuarPago2 = true;
                    bool _ContinuarPago3 = true;
                    bool _ContinuarPago4 = true;

                    double
                    _PagoDiecel = 0,
                    _PagoRegular = 0,
                    _PagoSuper = 0,
                    _PagoPremium = 0,

                    _DiecelQ = 0,
                    _RegularQ = 0,
                    _SuperQ = 0,
                    _PremiumQ = 0;
                    do
                    {

                        Console.WriteLine("\nIndique la cantidad que galones que desea: ");
                        Console.WriteLine("Aviso: Si ocurre algun error en su compra se le notificara su error y devera recolocar los datos.\n");
                        Console.WriteLine("* Diesel: "); _DiecelQ = double.Parse(Console.ReadLine());
                        Console.WriteLine("* Regular: "); _RegularQ = double.Parse(Console.ReadLine());
                        Console.WriteLine("* Super: "); _SuperQ = double.Parse(Console.ReadLine());
                        Console.WriteLine("* Premium: "); _PremiumQ = double.Parse(Console.ReadLine());

                        
                        //-------------------------------------------------- (Diesel) --------------------------------------------------

                        if (_DiecelQ < _DepoDiesel)
                        {

                            _ContinuarPago1 = true;
                            _PagoDiecel = _DiecelQ * _PrecioDiesel;

                        }

                        else if (_DiecelQ == _DepoDiesel)
                        {

                            _ContinuarPago1 = false;
                            Console.WriteLine("(Diesel) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                        }


                        else if (_DiecelQ > _DepoDiesel)
                        {

                            _ContinuarPago1 = false;
                            Console.WriteLine("(Diesel) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                        }

                        //-------------------------------------------------- (Regular) --------------------------------------------------

                        if (_RegularQ < _DepoRegular)
                        {

                            _ContinuarPago2 = true;
                            _PagoRegular = _RegularQ * _PrecioRegular;

                        }

                        else if (_RegularQ == _DepoRegular)
                        {

                            _ContinuarPago2 = false;
                            Console.WriteLine("(Regular) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                        }


                        else if (_RegularQ > _DepoRegular)
                        {

                            _ContinuarPago2 = false;
                            Console.WriteLine("(Regular) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                        }

                        //-------------------------------------------------- (Super) --------------------------------------------------

                        if (_SuperQ < _DepoSuper)
                        {

                            _ContinuarPago3 = true;
                            _PagoSuper = _SuperQ * _PrecioSuper;

                        }

                        else if (_SuperQ == _DepoSuper)
                        {

                            _ContinuarPago3 = false;
                            Console.WriteLine("(Super) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                        }


                        else if (_SuperQ > _DepoSuper)
                        {

                            _ContinuarPago3 = false;
                            Console.WriteLine("(Super) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                        }

                        //-------------------------------------------------- (Premium) --------------------------------------------------

                        if (_PremiumQ < _DepoPremium)
                        {

                            _ContinuarPago4 = true;
                            _PagoPremium = _PremiumQ * _PrecioPremium;

                        }

                        else if (_PremiumQ == _DepoPremium)
                        {

                            _ContinuarPago4 = false;
                            Console.WriteLine("(Premium) Error de compra 1: *La cantidad de galones pedida es la misma que la cantidad maxima.*");

                        }


                        else if (_PremiumQ > _DepoPremium)
                        {

                            _ContinuarPago4 = false;
                            Console.WriteLine("(Premium) Error de compra 2: *La cantidad de galones pedida sobrepasa la cantidad maxima.*");

                        }

                    }

                    while (_ContinuarPago1 == false); while (_ContinuarPago2 == false) ; while (_ContinuarPago3 == false) ; while (_ContinuarPago4 == false) ;

                    //  Nuevos galones

                    Console.WriteLine("\n*** COMPRA EXITOSA ***");

                    Console.WriteLine("\nGalones disponibles actuales:");
                    Console.WriteLine("* Diesel = " + (_DepoDiesel = _DepoDiesel + _DiecelQ) + "/2500 galones");
                    Console.WriteLine("* Regular = " + (_DepoRegular = _DepoRegular + _RegularQ) + "/2500 galones");
                    Console.WriteLine("* Super = " + (_DepoSuper = _DepoSuper + _SuperQ) + "/2500 galones");
                    Console.WriteLine("* Premium = " + (_DepoPremium = _DepoPremium + _PremiumQ) + "/2500 galones");

                    // Factura

                    Console.WriteLine("\nFACTURA: ");

                    double _Total = _PagoDiecel + _PagoRegular + _PagoSuper + _PagoPremium;

                    double
                    _IVADiesel = _PagoDiecel * 0.12,
                    _IVARegular = _PagoRegular * 0.12,
                    _IVASuper = _PagoSuper * 0.12,
                    _IVAPremium = _PagoPremium * 0.12;

                    double _TotalIVA = _IVADiesel + _IVARegular + _IVASuper + _IVAPremium;

                    double
                    _TODiesel = _PagoDiecel + _IVADiesel,
                    _TORegular = _PagoRegular + _IVARegular,
                    _TOSuper = _PagoSuper + _IVASuper,
                    _TOPremium = _PagoPremium + _IVAPremium;

                    double _TOTotal = _TODiesel + _TORegular + _TOSuper + _TOPremium;

                    double
                    _TOTALDiesel = _TODiesel * 1.11,
                    _TOTALRegular = _TORegular * 1.11,
                    _TOTALSuper = _TOSuper * 1.11,
                    _TOTALPremium = _TOPremium * 1.11;

                    double _TOTALTotal = _TOTALDiesel + _TOTALRegular + _TOTALSuper + _TOTALPremium;

                    Console.WriteLine("\nCosto por galones: ");
                    Console.WriteLine("* Diesel = Q. " + _PagoDiecel);
                    Console.WriteLine("* Regular = Q. " + _PagoRegular);
                    Console.WriteLine("* Super = Q. " + _PagoSuper);
                    Console.WriteLine("* Premium = Q. " + _PagoPremium);
                    Console.WriteLine("* Total: *** Q. " + _Total + " ***");

                    Console.WriteLine("\nCosto del IVA: ");
                    Console.WriteLine("* Diesel = Q. " + _IVADiesel);
                    Console.WriteLine("* Regular = Q. " + _IVARegular);
                    Console.WriteLine("* Super = Q. " + _IVASuper);
                    Console.WriteLine("* Premium = Q. " + _IVAPremium);
                    Console.WriteLine("* Total: *** Q. " + _TotalIVA + " ***");

                    Console.WriteLine("\nCosto con IVA: ");
                    Console.WriteLine("* Diesel = Q. " + _TODiesel);
                    Console.WriteLine("* Regular = Q. " + _TORegular);
                    Console.WriteLine("* Super = Q. " + _TOSuper);
                    Console.WriteLine("* Premium = Q. " + _TOPremium);
                    Console.WriteLine("* Total: *** Q. " + _TOTotal + " ***");

                    Console.WriteLine("\nCosto TOTAL / Final: ");
                    Console.WriteLine("* Diesel = Q. " + _TOTALDiesel);
                    Console.WriteLine("* Regular = Q. " + _TOTALRegular);
                    Console.WriteLine("* Super = Q. " + _TOTALSuper);
                    Console.WriteLine("* Premium = Q. " + _TOTALPremium);
                    Console.WriteLine("* Total: *** Q. " + _TOTALTotal + " ***");

                    try
                    {

                        // Metodo de pago

                        Console.WriteLine("\n¿Metodo de pago?");

                        Console.WriteLine("1. Al Credito ");
                        Console.WriteLine("2. Al Contado ");
                        bool Pago = true;

                        double
                        DeudaDeGasolinera = 0,
                        GananciasGasolinera = 0;

                        do
                        {

                            Console.WriteLine("\nElija el numero de lo que desea hacer: ");
                            int numero = int.Parse(Console.ReadLine());

                            switch (numero)
                            {

                                case 1:
                                    {

                                        Pago = true;
                                        Console.WriteLine("\nEligiste pagar: Al Credito.\n");
                                        DeudaDeGasolinera = -_TOTALTotal;
                                        Console.WriteLine("Deuda actual: " + DeudaDeGasolinera);

                                    }
                                    break;

                                case 2:
                                    {

                                        Pago = true;
                                        Console.WriteLine("\nEligiste pagar: Al Contador.\n");
                                        GananciasGasolinera = -_TOTALTotal;
                                        Console.WriteLine("Ganancias actuales: " + GananciasGasolinera);

                                    }
                                    break;

                                default:
                                    {

                                        Pago = false;
                                        Console.WriteLine("\n*** Porfavor eliga una de las opciones dadas. ***");

                                    }
                                    break;


                            }


                        }
                        while (Pago == false);

                    }
                    catch
                    {

                        Console.WriteLine("*** Se a producido un error en el programa, porfavor reinicie. ***");

                    }

                }

                else
                {

                 
                    Console.WriteLine("\nCompra Finalizada");

                }

            }
        }
            public void VentaCombustible(int tipoCombustible, int numeroBomba, int tipoVenta, int cantidad)
        {
            if (tipoVenta == 1)
            {
                if (tipoCombustible == 1)
                {
                    if (_depositoDiesel.Reversa < 25)
                    {

                        return;
                    }

                    if (_depositoDiesel.Reversa > cantidad)
                    {
                        switch (numeroBomba)
                        {
                            case 1:
                                _bomba1.DespacharCombustibleGalones(_depositoDiesel.combustible, cantidad);
                                break;
                            case 2:
                                _bomba2.DespacharCombustibleGalones(_depositoDiesel.combustible, cantidad);
                                break;
                            case 3:
                                _bomba3.DespacharCombustibleGalones(_depositoDiesel.combustible, cantidad);
                                break;
                            case 4:
                                _bomba4.DespacharCombustibleGalones(_depositoDiesel.combustible, cantidad);
                                break;
                            case 5:
                                _bomba5.DespacharCombustibleGalones(_depositoDiesel.combustible, cantidad);
                                break;
                        }
                    }
                }

            }
            if (tipoVenta == 2)
            {
                if (tipoCombustible == 2)
                {
                    if (_depositoRegular.Reversa < 25)
                    {

                        return;
                    }

                    if (_depositoRegular.Reversa > cantidad)
                    {
                        switch (numeroBomba)
                        {
                            case 1:
                                _bomba1.DespacharCombustibleGalones(_depositoRegular.combustible, cantidad);
                                break;
                            case 2:
                                _bomba2.DespacharCombustibleGalones(_depositoRegular.combustible, cantidad);
                                break;
                            case 3:
                                _bomba3.DespacharCombustibleGalones(_depositoRegular.combustible, cantidad);
                                break;
                            case 4:
                                _bomba4.DespacharCombustibleGalones(_depositoRegular.combustible, cantidad);
                                break;
                            case 5:
                                _bomba5.DespacharCombustibleGalones(_depositoRegular.combustible, cantidad);
                                break;
                        }
                    }
                }

            }
            if (tipoVenta == 3)
            {
                if (tipoCombustible == 3)
                {
                    if (_depositoSuper.Reversa < 25)
                    {

                        return;
                    }

                    if (_depositoSuper.Reversa > cantidad)
                    {
                        switch (numeroBomba)
                        {
                            case 1:
                                _bomba1.DespacharCombustibleGalones(_depositoSuper.combustible, cantidad);
                                break;
                            case 2:
                                _bomba2.DespacharCombustibleGalones(_depositoSuper.combustible, cantidad);
                                break;
                            case 3:
                                _bomba3.DespacharCombustibleGalones(_depositoSuper.combustible, cantidad);
                                break;
                            case 4:
                                _bomba4.DespacharCombustibleGalones(_depositoSuper.combustible, cantidad);
                                break;
                            case 5:
                                _bomba5.DespacharCombustibleGalones(_depositoSuper.combustible, cantidad);
                                break;
                        }
                    }
                }

            }
            if (tipoVenta == 4)
            {
                if (tipoCombustible == 4)
                {
                    if (_depositoPremium.Reversa < 25)
                    {

                        return;
                    }

                    if (_depositoPremium.Reversa > cantidad)
                    {
                        switch (numeroBomba)
                        {
                            case 1:
                                _bomba1.DespacharCombustibleGalones(_depositoPremium.combustible, cantidad);
                                break;
                            case 2:
                                _bomba2.DespacharCombustibleGalones(_depositoPremium.combustible, cantidad);
                                break;
                            case 3:
                                _bomba3.DespacharCombustibleGalones(_depositoPremium.combustible, cantidad);
                                break;
                            case 4:
                                _bomba4.DespacharCombustibleGalones(_depositoPremium.combustible, cantidad);
                                break;
                            case 5:
                                _bomba5.DespacharCombustibleGalones(_depositoPremium.combustible, cantidad);
                                break;
                        }
                    }
                }

            }

        }
    }
}
