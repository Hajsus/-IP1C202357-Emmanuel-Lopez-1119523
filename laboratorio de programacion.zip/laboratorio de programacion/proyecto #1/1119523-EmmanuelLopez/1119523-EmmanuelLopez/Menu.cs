﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1119523_EmmanuelLopez
{
    public class Menu
    {
        public void VentaAlCliente()
        {
            Console.WriteLine("Seleciono venta al cliente:");
            Console.ReadKey();
        }

        public void ReabastecimientoDeAlmacenes(string nombre)
        {
            Console.WriteLine("Seleciono reabastecimiento de almacen");
            Console.ReadKey();

        }

        public void Adios()
        {
            Console.WriteLine("Finalizado");
        }

        public void InformacionDeVentas()
        {
            Console.WriteLine("A elegido Reabastecimiento de los almacenes.");
            string _Usuario;
            string _Contraseña;
            bool _Continuar = false;
            try
            {
                do
                {

                    Console.WriteLine("Porfavor ingrese su usuario y contraseña. ");
                    _Usuario = Console.ReadLine();
                    _Contraseña = Console.ReadLine();

                    if (_Usuario == "Overflow1460" && _Contraseña == "23641122")
                    {

                        _Continuar = true;
                        Console.WriteLine("Bienvenido " + _Usuario);


                    }

                    else
                    {

                        _Continuar = false;
                        Console.WriteLine("Usuario y/o contraseña incorrecta \n");

                    }

                }

                while (_Continuar == false);

            }

            catch
            {

                Console.WriteLine("Ha ocurrido un error. Vuelva a intentarlo");

            }
        }
    }
}