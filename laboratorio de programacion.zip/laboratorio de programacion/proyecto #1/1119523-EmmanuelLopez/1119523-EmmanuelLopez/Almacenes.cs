﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1119523_EmmanuelLopez
{
    public class Almacen
    {
        public TipoDeGasolina combustible;
        public double Capacidad;
        public double Reversa;
    }
}
