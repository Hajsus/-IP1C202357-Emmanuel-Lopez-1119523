﻿namespace _1119523_EmmanuelLópez_Proyecto_2
{
    partial class Inicio
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.juego = new System.Windows.Forms.Button();
            this.configuraciones = new System.Windows.Forms.Button();
            this.tablas = new System.Windows.Forms.Button();
            this.Titulo = new System.Windows.Forms.Label();
            this.salir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // juego
            // 
            this.juego.Location = new System.Drawing.Point(655, 209);
            this.juego.Name = "juego";
            this.juego.Size = new System.Drawing.Size(94, 45);
            this.juego.TabIndex = 0;
            this.juego.Text = "Jugar";
            this.juego.UseVisualStyleBackColor = true;
            this.juego.Click += new System.EventHandler(this.juego_Click);
            // 
            // configuraciones
            // 
            this.configuraciones.Location = new System.Drawing.Point(634, 260);
            this.configuraciones.Name = "configuraciones";
            this.configuraciones.Size = new System.Drawing.Size(127, 43);
            this.configuraciones.TabIndex = 1;
            this.configuraciones.Text = "Configuraciones";
            this.configuraciones.UseVisualStyleBackColor = true;
            this.configuraciones.Click += new System.EventHandler(this.configuraciones_Click);
            // 
            // tablas
            // 
            this.tablas.Location = new System.Drawing.Point(634, 308);
            this.tablas.Name = "tablas";
            this.tablas.Size = new System.Drawing.Size(147, 48);
            this.tablas.TabIndex = 2;
            this.tablas.Text = "Tablas de partidas";
            this.tablas.UseVisualStyleBackColor = true;
            this.tablas.Click += new System.EventHandler(this.tablas_Click);
            // 
            // Titulo
            // 
            this.Titulo.AutoSize = true;
            this.Titulo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Titulo.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Titulo.Location = new System.Drawing.Point(410, 91);
            this.Titulo.Name = "Titulo";
            this.Titulo.Size = new System.Drawing.Size(664, 37);
            this.Titulo.TabIndex = 3;
            this.Titulo.Text = "The bindig of isaac: Revange of words";
            this.Titulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Titulo.Click += new System.EventHandler(this.TituloDelGame_Click);
            // 
            // salir
            // 
            this.salir.Location = new System.Drawing.Point(634, 380);
            this.salir.Name = "salir";
            this.salir.Size = new System.Drawing.Size(127, 43);
            this.salir.TabIndex = 4;
            this.salir.Text = "salir del juego";
            this.salir.UseVisualStyleBackColor = true;
            this.salir.Click += new System.EventHandler(this.button4_Click);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1378, 451);
            this.Controls.Add(this.salir);
            this.Controls.Add(this.Titulo);
            this.Controls.Add(this.tablas);
            this.Controls.Add(this.configuraciones);
            this.Controls.Add(this.juego);
            this.Name = "Inicio";
            this.Text = "the binding of isaac: revenge of words";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button juego;
        private Button configuraciones;
        private Button tablas;
        private Label Titulo;
        private Button salir;
    }
}