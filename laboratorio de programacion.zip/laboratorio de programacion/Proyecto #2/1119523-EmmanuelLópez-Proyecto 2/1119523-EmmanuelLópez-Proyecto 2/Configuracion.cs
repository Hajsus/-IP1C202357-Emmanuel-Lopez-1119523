﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1119523_EmmanuelLópez_Proyecto_2
{
    public partial class Configuracion : Form
    {
        Variables ClassVariables = new Variables();
        public Variables datosDeControles;
        public Configuracion()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BoxJ2_Click(object sender, EventArgs e)
        {
            if (ClassVariables.imagenTemporal != BoxJ1.Image)
            {
                ClassVariables.imagenJ2 = ClassVariables.imagenTemporal;
                BoxJ2.Image = ClassVariables.imagenTemporal;
            }
        }

        private void pictureBoxP1_Click(object sender, EventArgs e)
        {
            ClassVariables.imagenTemporal = pictureBoxP1.Image;
        }

        private void pictureBoxP2_Click(object sender, EventArgs e)
        {
            ClassVariables.imagenTemporal = pictureBoxP2.Image;
        }

        private void pictureBoxP3_Click(object sender, EventArgs e)
        {
            ClassVariables.imagenTemporal = pictureBoxP3.Image;
        }

        private void pictureBoxP4_Click(object sender, EventArgs e)
        {
            ClassVariables.imagenTemporal = pictureBoxP4.Image; 
        }

        private void pictureBoxP5_Click(object sender, EventArgs e)
        {
            ClassVariables.imagenTemporal = pictureBoxP5.Image;
        }

        private void BoxJ1_Click(object sender, EventArgs e)
        {
            if (ClassVariables.imagenTemporal != BoxJ2.Image)
            {
                ClassVariables.imagenTemporal = ClassVariables.imagenTemporal;
                BoxJ1.Image = ClassVariables.imagenTemporal;
            }
        }

        private void BotonGS_Click(object sender, EventArgs e)
        {
            if (datosDeControles == null)
            {
                datosDeControles = new Variables();
            }

            
            datosDeControles.tiempoP = int.Parse(TextBoxTiempoP.Text);
            datosDeControles.tiempoT = int.Parse(TextBoxTiempoT.Text);
            datosDeControles.nombreJ1 = J1.Text;
            datosDeControles.nombreJ2 = J2.Text;
            datosDeControles.imagenJ1 = BoxJ1.Image;
            datosDeControles.imagenJ2 = BoxJ2.Image;

            
            this.Close();
        }

        private void TextBoxTiempoP_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
