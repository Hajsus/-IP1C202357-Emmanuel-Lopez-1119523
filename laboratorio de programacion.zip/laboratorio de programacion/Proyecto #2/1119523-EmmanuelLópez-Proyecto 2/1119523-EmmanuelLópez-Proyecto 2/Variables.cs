﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1119523_EmmanuelLópez_Proyecto_2
{
    public class Variables
    { 
        public Image imagenTemporal;
        public int tiempoP;
        public int tiempoT;
        public Image imagenJ1;
        public Image imagenJ2;
        public string nombreJ1;
        public string nombreJ2;
    }
}
