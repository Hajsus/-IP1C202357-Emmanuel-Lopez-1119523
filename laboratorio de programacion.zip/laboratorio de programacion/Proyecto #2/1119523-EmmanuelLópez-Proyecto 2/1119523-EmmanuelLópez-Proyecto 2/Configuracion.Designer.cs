﻿namespace _1119523_EmmanuelLópez_Proyecto_2
{
    partial class Configuracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Configuracion));
            this.CajaAjustes = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BoxJ2 = new System.Windows.Forms.PictureBox();
            this.TextBoxTiempoT = new System.Windows.Forms.TextBox();
            this.TexTiempoT = new System.Windows.Forms.Label();
            this.TextBoxTiempoP = new System.Windows.Forms.TextBox();
            this.TexTiempoP = new System.Windows.Forms.Label();
            this.pictureBoxP5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxP4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxP3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxP2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxP1 = new System.Windows.Forms.PictureBox();
            this.TextoJ1 = new System.Windows.Forms.Label();
            this.BoxJ1 = new System.Windows.Forms.PictureBox();
            this.J2 = new System.Windows.Forms.TextBox();
            this.J1 = new System.Windows.Forms.TextBox();
            this.TextoJ2 = new System.Windows.Forms.Label();
            this.BotonGS = new System.Windows.Forms.Button();
            this.CajaAjustes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BoxJ2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxJ1)).BeginInit();
            this.SuspendLayout();
            // 
            // CajaAjustes
            // 
            this.CajaAjustes.Controls.Add(this.label1);
            this.CajaAjustes.Controls.Add(this.BoxJ2);
            this.CajaAjustes.Controls.Add(this.TextBoxTiempoT);
            this.CajaAjustes.Controls.Add(this.TexTiempoT);
            this.CajaAjustes.Controls.Add(this.TextBoxTiempoP);
            this.CajaAjustes.Controls.Add(this.TexTiempoP);
            this.CajaAjustes.Controls.Add(this.pictureBoxP5);
            this.CajaAjustes.Controls.Add(this.pictureBoxP4);
            this.CajaAjustes.Controls.Add(this.pictureBoxP3);
            this.CajaAjustes.Controls.Add(this.pictureBoxP2);
            this.CajaAjustes.Controls.Add(this.pictureBoxP1);
            this.CajaAjustes.Controls.Add(this.TextoJ1);
            this.CajaAjustes.Controls.Add(this.BoxJ1);
            this.CajaAjustes.Controls.Add(this.J2);
            this.CajaAjustes.Controls.Add(this.J1);
            this.CajaAjustes.Location = new System.Drawing.Point(14, 27);
            this.CajaAjustes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CajaAjustes.Name = "CajaAjustes";
            this.CajaAjustes.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CajaAjustes.Size = new System.Drawing.Size(887, 508);
            this.CajaAjustes.TabIndex = 21;
            this.CajaAjustes.TabStop = false;
            this.CajaAjustes.Text = "Ajustes de partida";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(746, 468);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 20);
            this.label1.TabIndex = 34;
            this.label1.Text = "Jugador 2";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // BoxJ2
            // 
            this.BoxJ2.Location = new System.Drawing.Point(707, 304);
            this.BoxJ2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BoxJ2.Name = "BoxJ2";
            this.BoxJ2.Size = new System.Drawing.Size(142, 157);
            this.BoxJ2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BoxJ2.TabIndex = 33;
            this.BoxJ2.TabStop = false;
            this.BoxJ2.Click += new System.EventHandler(this.BoxJ2_Click);
            // 
            // TextBoxTiempoT
            // 
            this.TextBoxTiempoT.Location = new System.Drawing.Point(373, 431);
            this.TextBoxTiempoT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TextBoxTiempoT.Name = "TextBoxTiempoT";
            this.TextBoxTiempoT.Size = new System.Drawing.Size(141, 27);
            this.TextBoxTiempoT.TabIndex = 32;
            this.TextBoxTiempoT.Text = "90";
            this.TextBoxTiempoT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TexTiempoT
            // 
            this.TexTiempoT.AutoSize = true;
            this.TexTiempoT.Location = new System.Drawing.Point(384, 388);
            this.TexTiempoT.Name = "TexTiempoT";
            this.TexTiempoT.Size = new System.Drawing.Size(132, 20);
            this.TexTiempoT.TabIndex = 31;
            this.TexTiempoT.Text = "Tiempo por turnos";
            // 
            // TextBoxTiempoP
            // 
            this.TextBoxTiempoP.Location = new System.Drawing.Point(373, 87);
            this.TextBoxTiempoP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TextBoxTiempoP.Name = "TextBoxTiempoP";
            this.TextBoxTiempoP.Size = new System.Drawing.Size(141, 27);
            this.TextBoxTiempoP.TabIndex = 30;
            this.TextBoxTiempoP.Text = "300";
            this.TextBoxTiempoP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TextBoxTiempoP.TextChanged += new System.EventHandler(this.TextBoxTiempoP_TextChanged);
            // 
            // TexTiempoP
            // 
            this.TexTiempoP.AutoSize = true;
            this.TexTiempoP.Location = new System.Drawing.Point(384, 39);
            this.TexTiempoP.Name = "TexTiempoP";
            this.TexTiempoP.Size = new System.Drawing.Size(133, 20);
            this.TexTiempoP.TabIndex = 29;
            this.TexTiempoP.Text = "Tiempo de partida";
            // 
            // pictureBoxP5
            // 
            this.pictureBoxP5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxP5.Image")));
            this.pictureBoxP5.Location = new System.Drawing.Point(707, 39);
            this.pictureBoxP5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBoxP5.Name = "pictureBoxP5";
            this.pictureBoxP5.Size = new System.Drawing.Size(142, 157);
            this.pictureBoxP5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxP5.TabIndex = 28;
            this.pictureBoxP5.TabStop = false;
            this.pictureBoxP5.Click += new System.EventHandler(this.pictureBoxP5_Click);
            // 
            // pictureBoxP4
            // 
            this.pictureBoxP4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxP4.Image")));
            this.pictureBoxP4.Location = new System.Drawing.Point(559, 39);
            this.pictureBoxP4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBoxP4.Name = "pictureBoxP4";
            this.pictureBoxP4.Size = new System.Drawing.Size(142, 157);
            this.pictureBoxP4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxP4.TabIndex = 27;
            this.pictureBoxP4.TabStop = false;
            this.pictureBoxP4.Click += new System.EventHandler(this.pictureBoxP4_Click);
            // 
            // pictureBoxP3
            // 
            this.pictureBoxP3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxP3.Image")));
            this.pictureBoxP3.Location = new System.Drawing.Point(362, 164);
            this.pictureBoxP3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBoxP3.Name = "pictureBoxP3";
            this.pictureBoxP3.Size = new System.Drawing.Size(142, 157);
            this.pictureBoxP3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxP3.TabIndex = 26;
            this.pictureBoxP3.TabStop = false;
            this.pictureBoxP3.Click += new System.EventHandler(this.pictureBoxP3_Click);
            // 
            // pictureBoxP2
            // 
            this.pictureBoxP2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxP2.Image")));
            this.pictureBoxP2.Location = new System.Drawing.Point(167, 311);
            this.pictureBoxP2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBoxP2.Name = "pictureBoxP2";
            this.pictureBoxP2.Size = new System.Drawing.Size(160, 157);
            this.pictureBoxP2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxP2.TabIndex = 25;
            this.pictureBoxP2.TabStop = false;
            this.pictureBoxP2.Click += new System.EventHandler(this.pictureBoxP2_Click);
            // 
            // pictureBoxP1
            // 
            this.pictureBoxP1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxP1.Image")));
            this.pictureBoxP1.Location = new System.Drawing.Point(18, 311);
            this.pictureBoxP1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBoxP1.Name = "pictureBoxP1";
            this.pictureBoxP1.Size = new System.Drawing.Size(142, 157);
            this.pictureBoxP1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxP1.TabIndex = 24;
            this.pictureBoxP1.TabStop = false;
            this.pictureBoxP1.Click += new System.EventHandler(this.pictureBoxP1_Click);
            // 
            // TextoJ1
            // 
            this.TextoJ1.AutoSize = true;
            this.TextoJ1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TextoJ1.Location = new System.Drawing.Point(102, 39);
            this.TextoJ1.Name = "TextoJ1";
            this.TextoJ1.Size = new System.Drawing.Size(79, 20);
            this.TextoJ1.TabIndex = 22;
            this.TextoJ1.Text = "Jugador 1";
            // 
            // BoxJ1
            // 
            this.BoxJ1.Location = new System.Drawing.Point(65, 63);
            this.BoxJ1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BoxJ1.Name = "BoxJ1";
            this.BoxJ1.Size = new System.Drawing.Size(142, 157);
            this.BoxJ1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BoxJ1.TabIndex = 20;
            this.BoxJ1.TabStop = false;
            this.BoxJ1.Click += new System.EventHandler(this.BoxJ1_Click);
            // 
            // J2
            // 
            this.J2.Location = new System.Drawing.Point(578, 265);
            this.J2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(301, 27);
            this.J2.TabIndex = 19;
            this.J2.Text = "nombre del Jugador 2";
            // 
            // J1
            // 
            this.J1.Location = new System.Drawing.Point(18, 252);
            this.J1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(301, 27);
            this.J1.TabIndex = 18;
            this.J1.Text = "nombre del Jugador 1";
            // 
            // TextoJ2
            // 
            this.TextoJ2.AutoSize = true;
            this.TextoJ2.Location = new System.Drawing.Point(721, 515);
            this.TextoJ2.Name = "TextoJ2";
            this.TextoJ2.Size = new System.Drawing.Size(158, 20);
            this.TextoJ2.TabIndex = 23;
            this.TextoJ2.Text = "Nombre del Jugador 2";
            // 
            // BotonGS
            // 
            this.BotonGS.Location = new System.Drawing.Point(241, 543);
            this.BotonGS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BotonGS.Name = "BotonGS";
            this.BotonGS.Size = new System.Drawing.Size(439, 31);
            this.BotonGS.TabIndex = 20;
            this.BotonGS.Text = "Guardar y salir";
            this.BotonGS.UseVisualStyleBackColor = true;
            this.BotonGS.Click += new System.EventHandler(this.BotonGS_Click);
            // 
            // Configuracion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.CajaAjustes);
            this.Controls.Add(this.BotonGS);
            this.Controls.Add(this.TextoJ2);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Configuracion";
            this.Text = "Configuraciones";
            this.CajaAjustes.ResumeLayout(false);
            this.CajaAjustes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BoxJ2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxJ1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox CajaAjustes;
        private Label label1;
        private PictureBox BoxJ2;
        private TextBox TextBoxTiempoT;
        private Label TexTiempoT;
        private TextBox TextBoxTiempoP;
        private Label TexTiempoP;
        private PictureBox pictureBoxP5;
        private PictureBox pictureBoxP4;
        private PictureBox pictureBoxP3;
        private PictureBox pictureBoxP2;
        private PictureBox pictureBoxP1;
        private Label TextoJ1;
        private PictureBox BoxJ1;
        private TextBox J2;
        private TextBox J1;
        private Label TextoJ2;
        private Button BotonGS;
    }
}