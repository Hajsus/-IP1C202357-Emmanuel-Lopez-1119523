﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1119523_EmmanuelLópez_Proyecto_2
{
    public partial class tablas : Form
    {
        public tablas()
        {
            InitializeComponent();
        }

        private void tablas_Load(object sender, EventArgs e)
        {

        }

        private void Cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Historial_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
