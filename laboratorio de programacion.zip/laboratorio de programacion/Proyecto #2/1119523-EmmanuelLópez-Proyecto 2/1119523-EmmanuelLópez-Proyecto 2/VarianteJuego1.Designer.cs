﻿namespace _1119523_EmmanuelLópez_Proyecto_2
{
    partial class VarianteJuego1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ListaDePistas1 = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.TexTiempoTG1 = new System.Windows.Forms.Label();
            this.TexTiempoPG1 = new System.Windows.Forms.Label();
            this.TextBoxTiempoTG1 = new System.Windows.Forms.TextBox();
            this.TextBoxTiempoPG1 = new System.Windows.Forms.TextBox();
            this.BotonFinalizar = new System.Windows.Forms.Button();
            this.PuntosJ2 = new System.Windows.Forms.TextBox();
            this.PuntosJ1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ImagenCJ1 = new System.Windows.Forms.PictureBox();
            this.NameCJ1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox283 = new System.Windows.Forms.TextBox();
            this.textBox284 = new System.Windows.Forms.TextBox();
            this.textBox285 = new System.Windows.Forms.TextBox();
            this.textBox286 = new System.Windows.Forms.TextBox();
            this.textBox282 = new System.Windows.Forms.TextBox();
            this.textBox281 = new System.Windows.Forms.TextBox();
            this.textBox274 = new System.Windows.Forms.TextBox();
            this.textBox275 = new System.Windows.Forms.TextBox();
            this.textBox276 = new System.Windows.Forms.TextBox();
            this.textBox277 = new System.Windows.Forms.TextBox();
            this.textBox278 = new System.Windows.Forms.TextBox();
            this.textBox279 = new System.Windows.Forms.TextBox();
            this.textBox280 = new System.Windows.Forms.TextBox();
            this.textBox269 = new System.Windows.Forms.TextBox();
            this.textBox260 = new System.Windows.Forms.TextBox();
            this.textBox261 = new System.Windows.Forms.TextBox();
            this.textBox262 = new System.Windows.Forms.TextBox();
            this.textBox263 = new System.Windows.Forms.TextBox();
            this.textBox264 = new System.Windows.Forms.TextBox();
            this.textBox265 = new System.Windows.Forms.TextBox();
            this.textBox266 = new System.Windows.Forms.TextBox();
            this.textBox267 = new System.Windows.Forms.TextBox();
            this.textBox268 = new System.Windows.Forms.TextBox();
            this.textBox252 = new System.Windows.Forms.TextBox();
            this.textBox253 = new System.Windows.Forms.TextBox();
            this.textBox256 = new System.Windows.Forms.TextBox();
            this.textBox257 = new System.Windows.Forms.TextBox();
            this.textBox258 = new System.Windows.Forms.TextBox();
            this.textBox259 = new System.Windows.Forms.TextBox();
            this.textBox239 = new System.Windows.Forms.TextBox();
            this.textBox248 = new System.Windows.Forms.TextBox();
            this.textBox249 = new System.Windows.Forms.TextBox();
            this.textBox250 = new System.Windows.Forms.TextBox();
            this.textBox251 = new System.Windows.Forms.TextBox();
            this.textBox254 = new System.Windows.Forms.TextBox();
            this.textBox255 = new System.Windows.Forms.TextBox();
            this.textBox241 = new System.Windows.Forms.TextBox();
            this.textBox242 = new System.Windows.Forms.TextBox();
            this.textBox243 = new System.Windows.Forms.TextBox();
            this.textBox244 = new System.Windows.Forms.TextBox();
            this.textBox245 = new System.Windows.Forms.TextBox();
            this.textBox246 = new System.Windows.Forms.TextBox();
            this.textBox247 = new System.Windows.Forms.TextBox();
            this.textBox240 = new System.Windows.Forms.TextBox();
            this.textBox228 = new System.Windows.Forms.TextBox();
            this.textBox229 = new System.Windows.Forms.TextBox();
            this.textBox230 = new System.Windows.Forms.TextBox();
            this.textBox231 = new System.Windows.Forms.TextBox();
            this.textBox232 = new System.Windows.Forms.TextBox();
            this.textBox233 = new System.Windows.Forms.TextBox();
            this.textBox234 = new System.Windows.Forms.TextBox();
            this.textBox235 = new System.Windows.Forms.TextBox();
            this.textBox236 = new System.Windows.Forms.TextBox();
            this.textBox237 = new System.Windows.Forms.TextBox();
            this.textBox238 = new System.Windows.Forms.TextBox();
            this.textBox227 = new System.Windows.Forms.TextBox();
            this.textBox226 = new System.Windows.Forms.TextBox();
            this.textBox219 = new System.Windows.Forms.TextBox();
            this.textBox220 = new System.Windows.Forms.TextBox();
            this.textBox221 = new System.Windows.Forms.TextBox();
            this.textBox222 = new System.Windows.Forms.TextBox();
            this.textBox223 = new System.Windows.Forms.TextBox();
            this.textBox224 = new System.Windows.Forms.TextBox();
            this.textBox225 = new System.Windows.Forms.TextBox();
            this.textBox210 = new System.Windows.Forms.TextBox();
            this.textBox211 = new System.Windows.Forms.TextBox();
            this.textBox212 = new System.Windows.Forms.TextBox();
            this.textBox213 = new System.Windows.Forms.TextBox();
            this.textBox214 = new System.Windows.Forms.TextBox();
            this.textBox215 = new System.Windows.Forms.TextBox();
            this.textBox216 = new System.Windows.Forms.TextBox();
            this.textBox217 = new System.Windows.Forms.TextBox();
            this.textBox218 = new System.Windows.Forms.TextBox();
            this.textBox199 = new System.Windows.Forms.TextBox();
            this.textBox200 = new System.Windows.Forms.TextBox();
            this.textBox201 = new System.Windows.Forms.TextBox();
            this.textBox202 = new System.Windows.Forms.TextBox();
            this.textBox203 = new System.Windows.Forms.TextBox();
            this.textBox204 = new System.Windows.Forms.TextBox();
            this.textBox205 = new System.Windows.Forms.TextBox();
            this.textBox206 = new System.Windows.Forms.TextBox();
            this.textBox207 = new System.Windows.Forms.TextBox();
            this.textBox208 = new System.Windows.Forms.TextBox();
            this.textBox209 = new System.Windows.Forms.TextBox();
            this.textBox188 = new System.Windows.Forms.TextBox();
            this.textBox189 = new System.Windows.Forms.TextBox();
            this.textBox190 = new System.Windows.Forms.TextBox();
            this.textBox191 = new System.Windows.Forms.TextBox();
            this.textBox192 = new System.Windows.Forms.TextBox();
            this.textBox193 = new System.Windows.Forms.TextBox();
            this.textBox194 = new System.Windows.Forms.TextBox();
            this.textBox195 = new System.Windows.Forms.TextBox();
            this.textBox196 = new System.Windows.Forms.TextBox();
            this.textBox197 = new System.Windows.Forms.TextBox();
            this.textBox198 = new System.Windows.Forms.TextBox();
            this.textBox176 = new System.Windows.Forms.TextBox();
            this.textBox177 = new System.Windows.Forms.TextBox();
            this.textBox178 = new System.Windows.Forms.TextBox();
            this.textBox179 = new System.Windows.Forms.TextBox();
            this.textBox180 = new System.Windows.Forms.TextBox();
            this.textBox181 = new System.Windows.Forms.TextBox();
            this.textBox182 = new System.Windows.Forms.TextBox();
            this.textBox183 = new System.Windows.Forms.TextBox();
            this.textBox184 = new System.Windows.Forms.TextBox();
            this.textBox185 = new System.Windows.Forms.TextBox();
            this.textBox186 = new System.Windows.Forms.TextBox();
            this.textBox187 = new System.Windows.Forms.TextBox();
            this.textBox175 = new System.Windows.Forms.TextBox();
            this.textBox172 = new System.Windows.Forms.TextBox();
            this.textBox173 = new System.Windows.Forms.TextBox();
            this.textBox174 = new System.Windows.Forms.TextBox();
            this.textBox171 = new System.Windows.Forms.TextBox();
            this.textBox162 = new System.Windows.Forms.TextBox();
            this.textBox163 = new System.Windows.Forms.TextBox();
            this.textBox164 = new System.Windows.Forms.TextBox();
            this.textBox165 = new System.Windows.Forms.TextBox();
            this.textBox166 = new System.Windows.Forms.TextBox();
            this.textBox167 = new System.Windows.Forms.TextBox();
            this.textBox168 = new System.Windows.Forms.TextBox();
            this.textBox169 = new System.Windows.Forms.TextBox();
            this.textBox170 = new System.Windows.Forms.TextBox();
            this.textBox153 = new System.Windows.Forms.TextBox();
            this.textBox154 = new System.Windows.Forms.TextBox();
            this.textBox155 = new System.Windows.Forms.TextBox();
            this.textBox156 = new System.Windows.Forms.TextBox();
            this.textBox157 = new System.Windows.Forms.TextBox();
            this.textBox158 = new System.Windows.Forms.TextBox();
            this.textBox159 = new System.Windows.Forms.TextBox();
            this.textBox160 = new System.Windows.Forms.TextBox();
            this.textBox161 = new System.Windows.Forms.TextBox();
            this.textBox141 = new System.Windows.Forms.TextBox();
            this.textBox142 = new System.Windows.Forms.TextBox();
            this.textBox144 = new System.Windows.Forms.TextBox();
            this.textBox147 = new System.Windows.Forms.TextBox();
            this.textBox148 = new System.Windows.Forms.TextBox();
            this.textBox149 = new System.Windows.Forms.TextBox();
            this.textBox150 = new System.Windows.Forms.TextBox();
            this.textBox151 = new System.Windows.Forms.TextBox();
            this.textBox152 = new System.Windows.Forms.TextBox();
            this.textBox139 = new System.Windows.Forms.TextBox();
            this.textBox137 = new System.Windows.Forms.TextBox();
            this.textBox136 = new System.Windows.Forms.TextBox();
            this.textBox138 = new System.Windows.Forms.TextBox();
            this.textBox140 = new System.Windows.Forms.TextBox();
            this.textBox143 = new System.Windows.Forms.TextBox();
            this.textBox145 = new System.Windows.Forms.TextBox();
            this.textBox146 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox117 = new System.Windows.Forms.TextBox();
            this.textBox123 = new System.Windows.Forms.TextBox();
            this.textBox127 = new System.Windows.Forms.TextBox();
            this.textBox129 = new System.Windows.Forms.TextBox();
            this.textBox130 = new System.Windows.Forms.TextBox();
            this.textBox131 = new System.Windows.Forms.TextBox();
            this.textBox132 = new System.Windows.Forms.TextBox();
            this.textBox133 = new System.Windows.Forms.TextBox();
            this.textBox134 = new System.Windows.Forms.TextBox();
            this.textBox135 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox128 = new System.Windows.Forms.TextBox();
            this.textBox126 = new System.Windows.Forms.TextBox();
            this.textBox125 = new System.Windows.Forms.TextBox();
            this.textBox124 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox122 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenCJ1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(33, 16);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(263, 459);
            this.tabControl1.TabIndex = 38;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ListaDePistas1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(255, 426);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Preguntas";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // ListaDePistas1
            // 
            this.ListaDePistas1.FormattingEnabled = true;
            this.ListaDePistas1.ItemHeight = 20;
            this.ListaDePistas1.Items.AddRange(new object[] {
            "Horizontal :",
            "",
            "1: ",
            "2: ",
            "3: ",
            "4: ",
            "5: ",
            "6: ",
            "7: ",
            "8: ",
            "9: ",
            "10: ",
            "11: ",
            "12: ",
            "13: ",
            "14: ",
            "15: ",
            "",
            "Vertical :",
            "",
            "1: ",
            "2: ",
            "3: ",
            "4: ",
            "5: ",
            "6: ",
            "7: ",
            "8: ",
            "9: ",
            "10: ",
            "11: ",
            "12: ",
            "13: ",
            "14: ",
            "15: "});
            this.ListaDePistas1.Location = new System.Drawing.Point(7, 7);
            this.ListaDePistas1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ListaDePistas1.Name = "ListaDePistas1";
            this.ListaDePistas1.Size = new System.Drawing.Size(239, 404);
            this.ListaDePistas1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(255, 426);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Respuestas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "Horizontal :",
            "",
            "1: c section",
            "2: polyphemus",
            "3: sacred heart",
            "4: the d6",
            "5: crickets head",
            "6: binge eater",
            "7: revelation",
            "8: incubus",
            "9: sacred orb",
            "10: haemolacria",
            "11: holy light ",
            "12: apple",
            "13: soy milk",
            "14: holy mantle",
            "15: mega blast",
            "",
            "",
            "Vertical :",
            "",
            "1: twisted pair",
            "2: abel",
            "3: brimstone",
            "4: tech x",
            "5: twenty twenty",
            "6: godhead",
            "7: stop watch",
            "8: mega mush",
            "9: spindown dice",
            "10: pyromaniac",
            "11: epic fetus",
            "12: crown of light",
            "13: d infinity",
            "14: backstabber",
            "15: chaos"});
            this.listBox1.Location = new System.Drawing.Point(3, 8);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(239, 404);
            this.listBox1.TabIndex = 38;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // TexTiempoTG1
            // 
            this.TexTiempoTG1.AutoSize = true;
            this.TexTiempoTG1.Location = new System.Drawing.Point(304, 112);
            this.TexTiempoTG1.Name = "TexTiempoTG1";
            this.TexTiempoTG1.Size = new System.Drawing.Size(127, 20);
            this.TexTiempoTG1.TabIndex = 42;
            this.TexTiempoTG1.Text = "Tiempo  de turno:";
            this.TexTiempoTG1.Click += new System.EventHandler(this.TexTiempoTG1_Click);
            // 
            // TexTiempoPG1
            // 
            this.TexTiempoPG1.AutoSize = true;
            this.TexTiempoPG1.Location = new System.Drawing.Point(303, 16);
            this.TexTiempoPG1.Name = "TexTiempoPG1";
            this.TexTiempoPG1.Size = new System.Drawing.Size(144, 20);
            this.TexTiempoPG1.TabIndex = 41;
            this.TexTiempoPG1.Text = "Tiempo de partida : ";
            // 
            // TextBoxTiempoTG1
            // 
            this.TextBoxTiempoTG1.Enabled = false;
            this.TextBoxTiempoTG1.Location = new System.Drawing.Point(303, 145);
            this.TextBoxTiempoTG1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TextBoxTiempoTG1.Name = "TextBoxTiempoTG1";
            this.TextBoxTiempoTG1.Size = new System.Drawing.Size(131, 27);
            this.TextBoxTiempoTG1.TabIndex = 40;
            // 
            // TextBoxTiempoPG1
            // 
            this.TextBoxTiempoPG1.Enabled = false;
            this.TextBoxTiempoPG1.Location = new System.Drawing.Point(303, 48);
            this.TextBoxTiempoPG1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TextBoxTiempoPG1.Name = "TextBoxTiempoPG1";
            this.TextBoxTiempoPG1.Size = new System.Drawing.Size(131, 27);
            this.TextBoxTiempoPG1.TabIndex = 39;
            // 
            // BotonFinalizar
            // 
            this.BotonFinalizar.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BotonFinalizar.Location = new System.Drawing.Point(22, 507);
            this.BotonFinalizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BotonFinalizar.Name = "BotonFinalizar";
            this.BotonFinalizar.Size = new System.Drawing.Size(127, 72);
            this.BotonFinalizar.TabIndex = 43;
            this.BotonFinalizar.Text = "finalizar turno";
            this.BotonFinalizar.UseVisualStyleBackColor = true;
            this.BotonFinalizar.Click += new System.EventHandler(this.BotonFinalizar_Click);
            // 
            // PuntosJ2
            // 
            this.PuntosJ2.Enabled = false;
            this.PuntosJ2.Location = new System.Drawing.Point(394, 548);
            this.PuntosJ2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PuntosJ2.Name = "PuntosJ2";
            this.PuntosJ2.Size = new System.Drawing.Size(54, 27);
            this.PuntosJ2.TabIndex = 48;
            // 
            // PuntosJ1
            // 
            this.PuntosJ1.Enabled = false;
            this.PuntosJ1.Location = new System.Drawing.Point(256, 548);
            this.PuntosJ1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PuntosJ1.Name = "PuntosJ1";
            this.PuntosJ1.Size = new System.Drawing.Size(54, 27);
            this.PuntosJ1.TabIndex = 47;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(321, 552);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 46;
            this.label3.Text = "Jugador 2 : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(183, 552);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 20);
            this.label2.TabIndex = 45;
            this.label2.Text = "Jugador 1 :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(250, 512);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 20);
            this.label1.TabIndex = 44;
            this.label1.Text = "Marcador de puntos :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(355, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 20);
            this.label5.TabIndex = 51;
            this.label5.Text = "Turno de : ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // ImagenCJ1
            // 
            this.ImagenCJ1.Location = new System.Drawing.Point(321, 232);
            this.ImagenCJ1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ImagenCJ1.Name = "ImagenCJ1";
            this.ImagenCJ1.Size = new System.Drawing.Size(142, 157);
            this.ImagenCJ1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ImagenCJ1.TabIndex = 50;
            this.ImagenCJ1.TabStop = false;
            this.ImagenCJ1.Click += new System.EventHandler(this.ImagenCJ1_Click);
            // 
            // NameCJ1
            // 
            this.NameCJ1.Enabled = false;
            this.NameCJ1.Location = new System.Drawing.Point(334, 397);
            this.NameCJ1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.NameCJ1.Name = "NameCJ1";
            this.NameCJ1.Size = new System.Drawing.Size(117, 27);
            this.NameCJ1.TabIndex = 49;
            this.NameCJ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NameCJ1.TextChanged += new System.EventHandler(this.NameCJ1_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox283);
            this.groupBox1.Controls.Add(this.textBox284);
            this.groupBox1.Controls.Add(this.textBox285);
            this.groupBox1.Controls.Add(this.textBox286);
            this.groupBox1.Controls.Add(this.textBox282);
            this.groupBox1.Controls.Add(this.textBox281);
            this.groupBox1.Controls.Add(this.textBox274);
            this.groupBox1.Controls.Add(this.textBox275);
            this.groupBox1.Controls.Add(this.textBox276);
            this.groupBox1.Controls.Add(this.textBox277);
            this.groupBox1.Controls.Add(this.textBox278);
            this.groupBox1.Controls.Add(this.textBox279);
            this.groupBox1.Controls.Add(this.textBox280);
            this.groupBox1.Controls.Add(this.textBox269);
            this.groupBox1.Controls.Add(this.textBox260);
            this.groupBox1.Controls.Add(this.textBox261);
            this.groupBox1.Controls.Add(this.textBox262);
            this.groupBox1.Controls.Add(this.textBox263);
            this.groupBox1.Controls.Add(this.textBox264);
            this.groupBox1.Controls.Add(this.textBox265);
            this.groupBox1.Controls.Add(this.textBox266);
            this.groupBox1.Controls.Add(this.textBox267);
            this.groupBox1.Controls.Add(this.textBox268);
            this.groupBox1.Controls.Add(this.textBox252);
            this.groupBox1.Controls.Add(this.textBox253);
            this.groupBox1.Controls.Add(this.textBox256);
            this.groupBox1.Controls.Add(this.textBox257);
            this.groupBox1.Controls.Add(this.textBox258);
            this.groupBox1.Controls.Add(this.textBox259);
            this.groupBox1.Controls.Add(this.textBox239);
            this.groupBox1.Controls.Add(this.textBox248);
            this.groupBox1.Controls.Add(this.textBox249);
            this.groupBox1.Controls.Add(this.textBox250);
            this.groupBox1.Controls.Add(this.textBox251);
            this.groupBox1.Controls.Add(this.textBox254);
            this.groupBox1.Controls.Add(this.textBox255);
            this.groupBox1.Controls.Add(this.textBox241);
            this.groupBox1.Controls.Add(this.textBox242);
            this.groupBox1.Controls.Add(this.textBox243);
            this.groupBox1.Controls.Add(this.textBox244);
            this.groupBox1.Controls.Add(this.textBox245);
            this.groupBox1.Controls.Add(this.textBox246);
            this.groupBox1.Controls.Add(this.textBox247);
            this.groupBox1.Controls.Add(this.textBox240);
            this.groupBox1.Controls.Add(this.textBox228);
            this.groupBox1.Controls.Add(this.textBox229);
            this.groupBox1.Controls.Add(this.textBox230);
            this.groupBox1.Controls.Add(this.textBox231);
            this.groupBox1.Controls.Add(this.textBox232);
            this.groupBox1.Controls.Add(this.textBox233);
            this.groupBox1.Controls.Add(this.textBox234);
            this.groupBox1.Controls.Add(this.textBox235);
            this.groupBox1.Controls.Add(this.textBox236);
            this.groupBox1.Controls.Add(this.textBox237);
            this.groupBox1.Controls.Add(this.textBox238);
            this.groupBox1.Controls.Add(this.textBox227);
            this.groupBox1.Controls.Add(this.textBox226);
            this.groupBox1.Controls.Add(this.textBox219);
            this.groupBox1.Controls.Add(this.textBox220);
            this.groupBox1.Controls.Add(this.textBox221);
            this.groupBox1.Controls.Add(this.textBox222);
            this.groupBox1.Controls.Add(this.textBox223);
            this.groupBox1.Controls.Add(this.textBox224);
            this.groupBox1.Controls.Add(this.textBox225);
            this.groupBox1.Controls.Add(this.textBox210);
            this.groupBox1.Controls.Add(this.textBox211);
            this.groupBox1.Controls.Add(this.textBox212);
            this.groupBox1.Controls.Add(this.textBox213);
            this.groupBox1.Controls.Add(this.textBox214);
            this.groupBox1.Controls.Add(this.textBox215);
            this.groupBox1.Controls.Add(this.textBox216);
            this.groupBox1.Controls.Add(this.textBox217);
            this.groupBox1.Controls.Add(this.textBox218);
            this.groupBox1.Controls.Add(this.textBox199);
            this.groupBox1.Controls.Add(this.textBox200);
            this.groupBox1.Controls.Add(this.textBox201);
            this.groupBox1.Controls.Add(this.textBox202);
            this.groupBox1.Controls.Add(this.textBox203);
            this.groupBox1.Controls.Add(this.textBox204);
            this.groupBox1.Controls.Add(this.textBox205);
            this.groupBox1.Controls.Add(this.textBox206);
            this.groupBox1.Controls.Add(this.textBox207);
            this.groupBox1.Controls.Add(this.textBox208);
            this.groupBox1.Controls.Add(this.textBox209);
            this.groupBox1.Controls.Add(this.textBox188);
            this.groupBox1.Controls.Add(this.textBox189);
            this.groupBox1.Controls.Add(this.textBox190);
            this.groupBox1.Controls.Add(this.textBox191);
            this.groupBox1.Controls.Add(this.textBox192);
            this.groupBox1.Controls.Add(this.textBox193);
            this.groupBox1.Controls.Add(this.textBox194);
            this.groupBox1.Controls.Add(this.textBox195);
            this.groupBox1.Controls.Add(this.textBox196);
            this.groupBox1.Controls.Add(this.textBox197);
            this.groupBox1.Controls.Add(this.textBox198);
            this.groupBox1.Controls.Add(this.textBox176);
            this.groupBox1.Controls.Add(this.textBox177);
            this.groupBox1.Controls.Add(this.textBox178);
            this.groupBox1.Controls.Add(this.textBox179);
            this.groupBox1.Controls.Add(this.textBox180);
            this.groupBox1.Controls.Add(this.textBox181);
            this.groupBox1.Controls.Add(this.textBox182);
            this.groupBox1.Controls.Add(this.textBox183);
            this.groupBox1.Controls.Add(this.textBox184);
            this.groupBox1.Controls.Add(this.textBox185);
            this.groupBox1.Controls.Add(this.textBox186);
            this.groupBox1.Controls.Add(this.textBox187);
            this.groupBox1.Controls.Add(this.textBox175);
            this.groupBox1.Controls.Add(this.textBox172);
            this.groupBox1.Controls.Add(this.textBox173);
            this.groupBox1.Controls.Add(this.textBox174);
            this.groupBox1.Controls.Add(this.textBox171);
            this.groupBox1.Controls.Add(this.textBox162);
            this.groupBox1.Controls.Add(this.textBox163);
            this.groupBox1.Controls.Add(this.textBox164);
            this.groupBox1.Controls.Add(this.textBox165);
            this.groupBox1.Controls.Add(this.textBox166);
            this.groupBox1.Controls.Add(this.textBox167);
            this.groupBox1.Controls.Add(this.textBox168);
            this.groupBox1.Controls.Add(this.textBox169);
            this.groupBox1.Controls.Add(this.textBox170);
            this.groupBox1.Controls.Add(this.textBox153);
            this.groupBox1.Controls.Add(this.textBox154);
            this.groupBox1.Controls.Add(this.textBox155);
            this.groupBox1.Controls.Add(this.textBox156);
            this.groupBox1.Controls.Add(this.textBox157);
            this.groupBox1.Controls.Add(this.textBox158);
            this.groupBox1.Controls.Add(this.textBox159);
            this.groupBox1.Controls.Add(this.textBox160);
            this.groupBox1.Controls.Add(this.textBox161);
            this.groupBox1.Controls.Add(this.textBox141);
            this.groupBox1.Controls.Add(this.textBox142);
            this.groupBox1.Controls.Add(this.textBox144);
            this.groupBox1.Controls.Add(this.textBox147);
            this.groupBox1.Controls.Add(this.textBox148);
            this.groupBox1.Controls.Add(this.textBox149);
            this.groupBox1.Controls.Add(this.textBox150);
            this.groupBox1.Controls.Add(this.textBox151);
            this.groupBox1.Controls.Add(this.textBox152);
            this.groupBox1.Controls.Add(this.textBox139);
            this.groupBox1.Controls.Add(this.textBox137);
            this.groupBox1.Controls.Add(this.textBox136);
            this.groupBox1.Controls.Add(this.textBox138);
            this.groupBox1.Controls.Add(this.textBox140);
            this.groupBox1.Controls.Add(this.textBox143);
            this.groupBox1.Controls.Add(this.textBox145);
            this.groupBox1.Controls.Add(this.textBox146);
            this.groupBox1.Controls.Add(this.textBox101);
            this.groupBox1.Controls.Add(this.textBox117);
            this.groupBox1.Controls.Add(this.textBox123);
            this.groupBox1.Controls.Add(this.textBox127);
            this.groupBox1.Controls.Add(this.textBox129);
            this.groupBox1.Controls.Add(this.textBox130);
            this.groupBox1.Controls.Add(this.textBox131);
            this.groupBox1.Controls.Add(this.textBox132);
            this.groupBox1.Controls.Add(this.textBox133);
            this.groupBox1.Controls.Add(this.textBox134);
            this.groupBox1.Controls.Add(this.textBox135);
            this.groupBox1.Controls.Add(this.textBox68);
            this.groupBox1.Controls.Add(this.textBox96);
            this.groupBox1.Controls.Add(this.textBox97);
            this.groupBox1.Controls.Add(this.textBox98);
            this.groupBox1.Controls.Add(this.textBox99);
            this.groupBox1.Controls.Add(this.textBox100);
            this.groupBox1.Controls.Add(this.textBox102);
            this.groupBox1.Controls.Add(this.textBox103);
            this.groupBox1.Controls.Add(this.textBox104);
            this.groupBox1.Controls.Add(this.textBox105);
            this.groupBox1.Controls.Add(this.textBox69);
            this.groupBox1.Controls.Add(this.textBox70);
            this.groupBox1.Controls.Add(this.textBox71);
            this.groupBox1.Controls.Add(this.textBox72);
            this.groupBox1.Controls.Add(this.textBox73);
            this.groupBox1.Controls.Add(this.textBox74);
            this.groupBox1.Controls.Add(this.textBox83);
            this.groupBox1.Controls.Add(this.textBox93);
            this.groupBox1.Controls.Add(this.textBox94);
            this.groupBox1.Controls.Add(this.textBox95);
            this.groupBox1.Controls.Add(this.textBox66);
            this.groupBox1.Controls.Add(this.textBox65);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox128);
            this.groupBox1.Controls.Add(this.textBox126);
            this.groupBox1.Controls.Add(this.textBox125);
            this.groupBox1.Controls.Add(this.textBox124);
            this.groupBox1.Controls.Add(this.textBox79);
            this.groupBox1.Controls.Add(this.textBox78);
            this.groupBox1.Controls.Add(this.textBox77);
            this.groupBox1.Controls.Add(this.textBox122);
            this.groupBox1.Controls.Add(this.textBox121);
            this.groupBox1.Controls.Add(this.textBox120);
            this.groupBox1.Controls.Add(this.textBox119);
            this.groupBox1.Controls.Add(this.textBox118);
            this.groupBox1.Controls.Add(this.textBox116);
            this.groupBox1.Controls.Add(this.textBox115);
            this.groupBox1.Controls.Add(this.textBox114);
            this.groupBox1.Controls.Add(this.textBox113);
            this.groupBox1.Controls.Add(this.textBox112);
            this.groupBox1.Controls.Add(this.textBox111);
            this.groupBox1.Controls.Add(this.textBox110);
            this.groupBox1.Controls.Add(this.textBox109);
            this.groupBox1.Controls.Add(this.textBox108);
            this.groupBox1.Controls.Add(this.textBox107);
            this.groupBox1.Controls.Add(this.textBox106);
            this.groupBox1.Controls.Add(this.textBox92);
            this.groupBox1.Controls.Add(this.textBox91);
            this.groupBox1.Controls.Add(this.textBox90);
            this.groupBox1.Controls.Add(this.textBox89);
            this.groupBox1.Controls.Add(this.textBox88);
            this.groupBox1.Controls.Add(this.textBox87);
            this.groupBox1.Controls.Add(this.textBox86);
            this.groupBox1.Controls.Add(this.textBox85);
            this.groupBox1.Controls.Add(this.textBox84);
            this.groupBox1.Controls.Add(this.textBox82);
            this.groupBox1.Controls.Add(this.textBox81);
            this.groupBox1.Controls.Add(this.textBox80);
            this.groupBox1.Controls.Add(this.textBox76);
            this.groupBox1.Controls.Add(this.textBox75);
            this.groupBox1.Controls.Add(this.textBox67);
            this.groupBox1.Controls.Add(this.textBox64);
            this.groupBox1.Controls.Add(this.textBox63);
            this.groupBox1.Controls.Add(this.textBox62);
            this.groupBox1.Controls.Add(this.textBox61);
            this.groupBox1.Controls.Add(this.textBox60);
            this.groupBox1.Controls.Add(this.textBox59);
            this.groupBox1.Controls.Add(this.textBox58);
            this.groupBox1.Controls.Add(this.textBox57);
            this.groupBox1.Controls.Add(this.textBox56);
            this.groupBox1.Controls.Add(this.textBox55);
            this.groupBox1.Controls.Add(this.textBox54);
            this.groupBox1.Controls.Add(this.textBox53);
            this.groupBox1.Controls.Add(this.textBox52);
            this.groupBox1.Controls.Add(this.textBox51);
            this.groupBox1.Controls.Add(this.textBox50);
            this.groupBox1.Controls.Add(this.textBox49);
            this.groupBox1.Controls.Add(this.textBox48);
            this.groupBox1.Controls.Add(this.textBox47);
            this.groupBox1.Controls.Add(this.textBox46);
            this.groupBox1.Controls.Add(this.textBox45);
            this.groupBox1.Controls.Add(this.textBox44);
            this.groupBox1.Controls.Add(this.textBox43);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.textBox12);
            this.groupBox1.Controls.Add(this.textBox13);
            this.groupBox1.Controls.Add(this.textBox14);
            this.groupBox1.Controls.Add(this.textBox15);
            this.groupBox1.Controls.Add(this.textBox16);
            this.groupBox1.Controls.Add(this.textBox17);
            this.groupBox1.Controls.Add(this.textBox18);
            this.groupBox1.Controls.Add(this.textBox19);
            this.groupBox1.Controls.Add(this.textBox20);
            this.groupBox1.Controls.Add(this.textBox21);
            this.groupBox1.Controls.Add(this.textBox22);
            this.groupBox1.Controls.Add(this.textBox23);
            this.groupBox1.Controls.Add(this.textBox24);
            this.groupBox1.Controls.Add(this.textBox25);
            this.groupBox1.Controls.Add(this.textBox26);
            this.groupBox1.Controls.Add(this.textBox27);
            this.groupBox1.Controls.Add(this.textBox28);
            this.groupBox1.Controls.Add(this.textBox29);
            this.groupBox1.Controls.Add(this.textBox30);
            this.groupBox1.Controls.Add(this.textBox31);
            this.groupBox1.Controls.Add(this.textBox32);
            this.groupBox1.Controls.Add(this.textBox33);
            this.groupBox1.Controls.Add(this.textBox34);
            this.groupBox1.Controls.Add(this.textBox35);
            this.groupBox1.Controls.Add(this.textBox36);
            this.groupBox1.Controls.Add(this.textBox37);
            this.groupBox1.Controls.Add(this.textBox38);
            this.groupBox1.Controls.Add(this.textBox39);
            this.groupBox1.Controls.Add(this.textBox40);
            this.groupBox1.Controls.Add(this.textBox41);
            this.groupBox1.Controls.Add(this.textBox42);
            this.groupBox1.Location = new System.Drawing.Point(488, 40);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(968, 984);
            this.groupBox1.TabIndex = 231;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "juego";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // textBox283
            // 
            this.textBox283.Location = new System.Drawing.Point(677, 52);
            this.textBox283.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox283.Multiline = true;
            this.textBox283.Name = "textBox283";
            this.textBox283.Size = new System.Drawing.Size(27, 24);
            this.textBox283.TabIndex = 499;
            this.textBox283.Text = "2.";
            this.textBox283.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox284
            // 
            this.textBox284.Location = new System.Drawing.Point(681, 154);
            this.textBox284.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox284.Multiline = true;
            this.textBox284.Name = "textBox284";
            this.textBox284.Size = new System.Drawing.Size(20, 24);
            this.textBox284.TabIndex = 498;
            this.textBox284.Text = " ";
            this.textBox284.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox285
            // 
            this.textBox285.Location = new System.Drawing.Point(681, 90);
            this.textBox285.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox285.Multiline = true;
            this.textBox285.Name = "textBox285";
            this.textBox285.Size = new System.Drawing.Size(20, 24);
            this.textBox285.TabIndex = 497;
            this.textBox285.Text = " ";
            this.textBox285.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox286
            // 
            this.textBox286.Location = new System.Drawing.Point(681, 186);
            this.textBox286.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox286.Multiline = true;
            this.textBox286.Name = "textBox286";
            this.textBox286.Size = new System.Drawing.Size(20, 24);
            this.textBox286.TabIndex = 496;
            this.textBox286.Text = " ";
            this.textBox286.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox282
            // 
            this.textBox282.Location = new System.Drawing.Point(379, 439);
            this.textBox282.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox282.Multiline = true;
            this.textBox282.Name = "textBox282";
            this.textBox282.Size = new System.Drawing.Size(20, 24);
            this.textBox282.TabIndex = 495;
            this.textBox282.Text = " ";
            this.textBox282.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox281
            // 
            this.textBox281.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox281.Location = new System.Drawing.Point(379, 193);
            this.textBox281.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox281.Multiline = true;
            this.textBox281.Name = "textBox281";
            this.textBox281.Size = new System.Drawing.Size(20, 24);
            this.textBox281.TabIndex = 494;
            this.textBox281.Text = " ";
            this.textBox281.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox274
            // 
            this.textBox274.Location = new System.Drawing.Point(379, 407);
            this.textBox274.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox274.Multiline = true;
            this.textBox274.Name = "textBox274";
            this.textBox274.Size = new System.Drawing.Size(20, 24);
            this.textBox274.TabIndex = 493;
            this.textBox274.Text = " ";
            this.textBox274.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox275
            // 
            this.textBox275.Location = new System.Drawing.Point(379, 346);
            this.textBox275.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox275.Multiline = true;
            this.textBox275.Name = "textBox275";
            this.textBox275.Size = new System.Drawing.Size(20, 24);
            this.textBox275.TabIndex = 492;
            this.textBox275.Text = " ";
            this.textBox275.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox276
            // 
            this.textBox276.Location = new System.Drawing.Point(379, 317);
            this.textBox276.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox276.Multiline = true;
            this.textBox276.Name = "textBox276";
            this.textBox276.Size = new System.Drawing.Size(20, 24);
            this.textBox276.TabIndex = 491;
            this.textBox276.Text = " ";
            this.textBox276.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox277
            // 
            this.textBox277.Location = new System.Drawing.Point(379, 284);
            this.textBox277.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox277.Multiline = true;
            this.textBox277.Name = "textBox277";
            this.textBox277.Size = new System.Drawing.Size(20, 24);
            this.textBox277.TabIndex = 490;
            this.textBox277.Text = " ";
            this.textBox277.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox278
            // 
            this.textBox278.Location = new System.Drawing.Point(379, 256);
            this.textBox278.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox278.Multiline = true;
            this.textBox278.Name = "textBox278";
            this.textBox278.Size = new System.Drawing.Size(20, 24);
            this.textBox278.TabIndex = 489;
            this.textBox278.Text = " ";
            this.textBox278.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox279
            // 
            this.textBox279.Location = new System.Drawing.Point(379, 222);
            this.textBox279.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox279.Multiline = true;
            this.textBox279.Name = "textBox279";
            this.textBox279.Size = new System.Drawing.Size(20, 24);
            this.textBox279.TabIndex = 488;
            this.textBox279.Text = " ";
            this.textBox279.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox280
            // 
            this.textBox280.Location = new System.Drawing.Point(379, 161);
            this.textBox280.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox280.Multiline = true;
            this.textBox280.Name = "textBox280";
            this.textBox280.Size = new System.Drawing.Size(20, 24);
            this.textBox280.TabIndex = 487;
            this.textBox280.Text = " ";
            this.textBox280.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox269
            // 
            this.textBox269.Enabled = false;
            this.textBox269.Location = new System.Drawing.Point(924, 648);
            this.textBox269.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox269.Multiline = true;
            this.textBox269.Name = "textBox269";
            this.textBox269.Size = new System.Drawing.Size(20, 24);
            this.textBox269.TabIndex = 482;
            this.textBox269.Text = " ";
            this.textBox269.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox260
            // 
            this.textBox260.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox260.Location = new System.Drawing.Point(792, 650);
            this.textBox260.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox260.Multiline = true;
            this.textBox260.Name = "textBox260";
            this.textBox260.Size = new System.Drawing.Size(20, 24);
            this.textBox260.TabIndex = 481;
            this.textBox260.Text = "15.";
            this.textBox260.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox261
            // 
            this.textBox261.Location = new System.Drawing.Point(842, 648);
            this.textBox261.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox261.Multiline = true;
            this.textBox261.Name = "textBox261";
            this.textBox261.Size = new System.Drawing.Size(23, 24);
            this.textBox261.TabIndex = 480;
            this.textBox261.Text = " ";
            this.textBox261.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox262
            // 
            this.textBox262.Location = new System.Drawing.Point(817, 648);
            this.textBox262.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox262.Multiline = true;
            this.textBox262.Name = "textBox262";
            this.textBox262.Size = new System.Drawing.Size(23, 24);
            this.textBox262.TabIndex = 479;
            this.textBox262.Text = " ";
            this.textBox262.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox263
            // 
            this.textBox263.Location = new System.Drawing.Point(895, 648);
            this.textBox263.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox263.Multiline = true;
            this.textBox263.Name = "textBox263";
            this.textBox263.Size = new System.Drawing.Size(23, 24);
            this.textBox263.TabIndex = 478;
            this.textBox263.Text = " ";
            this.textBox263.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox264
            // 
            this.textBox264.Location = new System.Drawing.Point(733, 650);
            this.textBox264.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox264.Multiline = true;
            this.textBox264.Name = "textBox264";
            this.textBox264.Size = new System.Drawing.Size(23, 24);
            this.textBox264.TabIndex = 477;
            this.textBox264.Text = " ";
            this.textBox264.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox265
            // 
            this.textBox265.Location = new System.Drawing.Point(762, 650);
            this.textBox265.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox265.Multiline = true;
            this.textBox265.Name = "textBox265";
            this.textBox265.Size = new System.Drawing.Size(23, 24);
            this.textBox265.TabIndex = 476;
            this.textBox265.Text = " ";
            this.textBox265.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox266
            // 
            this.textBox266.Location = new System.Drawing.Point(705, 650);
            this.textBox266.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox266.Multiline = true;
            this.textBox266.Name = "textBox266";
            this.textBox266.Size = new System.Drawing.Size(20, 24);
            this.textBox266.TabIndex = 475;
            this.textBox266.Text = " ";
            this.textBox266.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox267
            // 
            this.textBox267.Location = new System.Drawing.Point(650, 650);
            this.textBox267.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox267.Multiline = true;
            this.textBox267.Name = "textBox267";
            this.textBox267.Size = new System.Drawing.Size(28, 24);
            this.textBox267.TabIndex = 474;
            this.textBox267.Text = "15.";
            this.textBox267.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox268
            // 
            this.textBox268.Location = new System.Drawing.Point(681, 650);
            this.textBox268.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox268.Multiline = true;
            this.textBox268.Name = "textBox268";
            this.textBox268.Size = new System.Drawing.Size(20, 24);
            this.textBox268.TabIndex = 473;
            this.textBox268.Text = " ";
            this.textBox268.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox252
            // 
            this.textBox252.Location = new System.Drawing.Point(869, 746);
            this.textBox252.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox252.Multiline = true;
            this.textBox252.Name = "textBox252";
            this.textBox252.Size = new System.Drawing.Size(20, 24);
            this.textBox252.TabIndex = 472;
            this.textBox252.Text = " ";
            this.textBox252.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox253
            // 
            this.textBox253.Location = new System.Drawing.Point(869, 781);
            this.textBox253.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox253.Multiline = true;
            this.textBox253.Name = "textBox253";
            this.textBox253.Size = new System.Drawing.Size(20, 24);
            this.textBox253.TabIndex = 471;
            this.textBox253.Text = " ";
            this.textBox253.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox256
            // 
            this.textBox256.Location = new System.Drawing.Point(869, 846);
            this.textBox256.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox256.Multiline = true;
            this.textBox256.Name = "textBox256";
            this.textBox256.Size = new System.Drawing.Size(20, 24);
            this.textBox256.TabIndex = 470;
            this.textBox256.Text = " ";
            this.textBox256.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox257
            // 
            this.textBox257.Location = new System.Drawing.Point(869, 911);
            this.textBox257.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox257.Multiline = true;
            this.textBox257.Name = "textBox257";
            this.textBox257.Size = new System.Drawing.Size(20, 24);
            this.textBox257.TabIndex = 469;
            this.textBox257.Text = " ";
            this.textBox257.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox258
            // 
            this.textBox258.Location = new System.Drawing.Point(869, 879);
            this.textBox258.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox258.Multiline = true;
            this.textBox258.Name = "textBox258";
            this.textBox258.Size = new System.Drawing.Size(20, 24);
            this.textBox258.TabIndex = 468;
            this.textBox258.Text = " ";
            this.textBox258.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox259
            // 
            this.textBox259.Location = new System.Drawing.Point(869, 813);
            this.textBox259.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox259.Multiline = true;
            this.textBox259.Name = "textBox259";
            this.textBox259.Size = new System.Drawing.Size(20, 24);
            this.textBox259.TabIndex = 467;
            this.textBox259.Text = " ";
            this.textBox259.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox239
            // 
            this.textBox239.BackColor = System.Drawing.Color.White;
            this.textBox239.Location = new System.Drawing.Point(869, 482);
            this.textBox239.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox239.Multiline = true;
            this.textBox239.Name = "textBox239";
            this.textBox239.Size = new System.Drawing.Size(20, 24);
            this.textBox239.TabIndex = 466;
            this.textBox239.Text = "5.";
            this.textBox239.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox248
            // 
            this.textBox248.Location = new System.Drawing.Point(869, 515);
            this.textBox248.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox248.Multiline = true;
            this.textBox248.Name = "textBox248";
            this.textBox248.Size = new System.Drawing.Size(20, 24);
            this.textBox248.TabIndex = 465;
            this.textBox248.Text = " ";
            this.textBox248.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox249
            // 
            this.textBox249.Location = new System.Drawing.Point(869, 550);
            this.textBox249.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox249.Multiline = true;
            this.textBox249.Name = "textBox249";
            this.textBox249.Size = new System.Drawing.Size(20, 24);
            this.textBox249.TabIndex = 464;
            this.textBox249.Text = " ";
            this.textBox249.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox250
            // 
            this.textBox250.Location = new System.Drawing.Point(869, 615);
            this.textBox250.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox250.Multiline = true;
            this.textBox250.Name = "textBox250";
            this.textBox250.Size = new System.Drawing.Size(20, 24);
            this.textBox250.TabIndex = 463;
            this.textBox250.Text = " ";
            this.textBox250.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox251
            // 
            this.textBox251.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox251.Location = new System.Drawing.Point(869, 718);
            this.textBox251.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox251.Multiline = true;
            this.textBox251.Name = "textBox251";
            this.textBox251.Size = new System.Drawing.Size(20, 24);
            this.textBox251.TabIndex = 462;
            this.textBox251.Text = " ";
            this.textBox251.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox254
            // 
            this.textBox254.Location = new System.Drawing.Point(869, 680);
            this.textBox254.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox254.Multiline = true;
            this.textBox254.Name = "textBox254";
            this.textBox254.Size = new System.Drawing.Size(20, 24);
            this.textBox254.TabIndex = 459;
            this.textBox254.Text = " ";
            this.textBox254.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox255
            // 
            this.textBox255.Location = new System.Drawing.Point(869, 648);
            this.textBox255.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox255.Multiline = true;
            this.textBox255.Name = "textBox255";
            this.textBox255.Size = new System.Drawing.Size(20, 24);
            this.textBox255.TabIndex = 458;
            this.textBox255.Text = " ";
            this.textBox255.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox241
            // 
            this.textBox241.Location = new System.Drawing.Point(896, 582);
            this.textBox241.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox241.Multiline = true;
            this.textBox241.Name = "textBox241";
            this.textBox241.Size = new System.Drawing.Size(20, 24);
            this.textBox241.TabIndex = 457;
            this.textBox241.Text = " ";
            this.textBox241.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox242
            // 
            this.textBox242.Location = new System.Drawing.Point(869, 582);
            this.textBox242.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox242.Multiline = true;
            this.textBox242.Name = "textBox242";
            this.textBox242.Size = new System.Drawing.Size(20, 24);
            this.textBox242.TabIndex = 456;
            this.textBox242.Text = " ";
            this.textBox242.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox243
            // 
            this.textBox243.Location = new System.Drawing.Point(842, 582);
            this.textBox243.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox243.Multiline = true;
            this.textBox243.Name = "textBox243";
            this.textBox243.Size = new System.Drawing.Size(20, 24);
            this.textBox243.TabIndex = 455;
            this.textBox243.Text = " ";
            this.textBox243.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox244
            // 
            this.textBox244.Location = new System.Drawing.Point(814, 582);
            this.textBox244.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox244.Multiline = true;
            this.textBox244.Name = "textBox244";
            this.textBox244.Size = new System.Drawing.Size(20, 24);
            this.textBox244.TabIndex = 454;
            this.textBox244.Text = " ";
            this.textBox244.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox245
            // 
            this.textBox245.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox245.Location = new System.Drawing.Point(766, 582);
            this.textBox245.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox245.Multiline = true;
            this.textBox245.Name = "textBox245";
            this.textBox245.Size = new System.Drawing.Size(20, 24);
            this.textBox245.TabIndex = 453;
            this.textBox245.Text = "e";
            this.textBox245.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox246
            // 
            this.textBox246.Location = new System.Drawing.Point(789, 581);
            this.textBox246.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox246.Multiline = true;
            this.textBox246.Name = "textBox246";
            this.textBox246.Size = new System.Drawing.Size(20, 24);
            this.textBox246.TabIndex = 452;
            this.textBox246.Text = " ";
            this.textBox246.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox247
            // 
            this.textBox247.Location = new System.Drawing.Point(737, 582);
            this.textBox247.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox247.Multiline = true;
            this.textBox247.Name = "textBox247";
            this.textBox247.Size = new System.Drawing.Size(20, 24);
            this.textBox247.TabIndex = 451;
            this.textBox247.Text = " ";
            this.textBox247.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox240
            // 
            this.textBox240.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox240.Location = new System.Drawing.Point(708, 718);
            this.textBox240.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox240.Multiline = true;
            this.textBox240.Name = "textBox240";
            this.textBox240.Size = new System.Drawing.Size(20, 24);
            this.textBox240.TabIndex = 449;
            this.textBox240.Text = " ";
            this.textBox240.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox228
            // 
            this.textBox228.Location = new System.Drawing.Point(654, 582);
            this.textBox228.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox228.Multiline = true;
            this.textBox228.Name = "textBox228";
            this.textBox228.Size = new System.Drawing.Size(24, 24);
            this.textBox228.TabIndex = 448;
            this.textBox228.Text = " ";
            this.textBox228.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox229
            // 
            this.textBox229.Location = new System.Drawing.Point(684, 582);
            this.textBox229.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox229.Multiline = true;
            this.textBox229.Name = "textBox229";
            this.textBox229.Size = new System.Drawing.Size(24, 24);
            this.textBox229.TabIndex = 447;
            this.textBox229.Text = " ";
            this.textBox229.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox230
            // 
            this.textBox230.Location = new System.Drawing.Point(788, 718);
            this.textBox230.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox230.Multiline = true;
            this.textBox230.Name = "textBox230";
            this.textBox230.Size = new System.Drawing.Size(23, 24);
            this.textBox230.TabIndex = 446;
            this.textBox230.Text = " ";
            this.textBox230.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox231
            // 
            this.textBox231.Location = new System.Drawing.Point(763, 718);
            this.textBox231.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox231.Multiline = true;
            this.textBox231.Name = "textBox231";
            this.textBox231.Size = new System.Drawing.Size(23, 24);
            this.textBox231.TabIndex = 445;
            this.textBox231.Text = " ";
            this.textBox231.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox232
            // 
            this.textBox232.Location = new System.Drawing.Point(816, 718);
            this.textBox232.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox232.Multiline = true;
            this.textBox232.Name = "textBox232";
            this.textBox232.Size = new System.Drawing.Size(23, 24);
            this.textBox232.TabIndex = 444;
            this.textBox232.Text = " ";
            this.textBox232.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox233
            // 
            this.textBox233.Location = new System.Drawing.Point(601, 582);
            this.textBox233.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox233.Multiline = true;
            this.textBox233.Name = "textBox233";
            this.textBox233.Size = new System.Drawing.Size(23, 24);
            this.textBox233.TabIndex = 443;
            this.textBox233.Text = "6.";
            this.textBox233.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox234
            // 
            this.textBox234.Location = new System.Drawing.Point(679, 718);
            this.textBox234.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox234.Multiline = true;
            this.textBox234.Name = "textBox234";
            this.textBox234.Size = new System.Drawing.Size(23, 24);
            this.textBox234.TabIndex = 442;
            this.textBox234.Text = " ";
            this.textBox234.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox235
            // 
            this.textBox235.Location = new System.Drawing.Point(735, 718);
            this.textBox235.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox235.Multiline = true;
            this.textBox235.Name = "textBox235";
            this.textBox235.Size = new System.Drawing.Size(23, 24);
            this.textBox235.TabIndex = 441;
            this.textBox235.Text = " ";
            this.textBox235.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox236
            // 
            this.textBox236.Location = new System.Drawing.Point(651, 718);
            this.textBox236.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox236.Multiline = true;
            this.textBox236.Name = "textBox236";
            this.textBox236.Size = new System.Drawing.Size(20, 24);
            this.textBox236.TabIndex = 440;
            this.textBox236.Text = " ";
            this.textBox236.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox237
            // 
            this.textBox237.Location = new System.Drawing.Point(710, 582);
            this.textBox237.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox237.Multiline = true;
            this.textBox237.Name = "textBox237";
            this.textBox237.Size = new System.Drawing.Size(24, 24);
            this.textBox237.TabIndex = 439;
            this.textBox237.Text = " ";
            this.textBox237.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox238
            // 
            this.textBox238.Location = new System.Drawing.Point(597, 718);
            this.textBox238.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox238.Multiline = true;
            this.textBox238.Name = "textBox238";
            this.textBox238.Size = new System.Drawing.Size(27, 24);
            this.textBox238.TabIndex = 438;
            this.textBox238.Text = "13.";
            this.textBox238.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox227
            // 
            this.textBox227.Location = new System.Drawing.Point(875, 450);
            this.textBox227.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox227.Multiline = true;
            this.textBox227.Name = "textBox227";
            this.textBox227.Size = new System.Drawing.Size(24, 24);
            this.textBox227.TabIndex = 436;
            this.textBox227.Text = " ";
            this.textBox227.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox226
            // 
            this.textBox226.Location = new System.Drawing.Point(905, 450);
            this.textBox226.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox226.Multiline = true;
            this.textBox226.Name = "textBox226";
            this.textBox226.Size = new System.Drawing.Size(24, 24);
            this.textBox226.TabIndex = 435;
            this.textBox226.Text = " ";
            this.textBox226.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox219
            // 
            this.textBox219.Location = new System.Drawing.Point(761, 450);
            this.textBox219.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox219.Multiline = true;
            this.textBox219.Name = "textBox219";
            this.textBox219.Size = new System.Drawing.Size(23, 24);
            this.textBox219.TabIndex = 434;
            this.textBox219.Text = " ";
            this.textBox219.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox220
            // 
            this.textBox220.Location = new System.Drawing.Point(736, 450);
            this.textBox220.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox220.Multiline = true;
            this.textBox220.Name = "textBox220";
            this.textBox220.Size = new System.Drawing.Size(23, 24);
            this.textBox220.TabIndex = 433;
            this.textBox220.Text = " ";
            this.textBox220.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox221
            // 
            this.textBox221.Location = new System.Drawing.Point(789, 450);
            this.textBox221.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox221.Multiline = true;
            this.textBox221.Name = "textBox221";
            this.textBox221.Size = new System.Drawing.Size(23, 24);
            this.textBox221.TabIndex = 432;
            this.textBox221.Text = " ";
            this.textBox221.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox222
            // 
            this.textBox222.Location = new System.Drawing.Point(816, 450);
            this.textBox222.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox222.Multiline = true;
            this.textBox222.Name = "textBox222";
            this.textBox222.Size = new System.Drawing.Size(23, 24);
            this.textBox222.TabIndex = 431;
            this.textBox222.Text = " ";
            this.textBox222.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox223
            // 
            this.textBox223.Location = new System.Drawing.Point(681, 450);
            this.textBox223.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox223.Multiline = true;
            this.textBox223.Name = "textBox223";
            this.textBox223.Size = new System.Drawing.Size(23, 24);
            this.textBox223.TabIndex = 430;
            this.textBox223.Text = " ";
            this.textBox223.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox224
            // 
            this.textBox224.Location = new System.Drawing.Point(708, 450);
            this.textBox224.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox224.Multiline = true;
            this.textBox224.Name = "textBox224";
            this.textBox224.Size = new System.Drawing.Size(23, 24);
            this.textBox224.TabIndex = 429;
            this.textBox224.Text = " ";
            this.textBox224.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox225
            // 
            this.textBox225.Location = new System.Drawing.Point(653, 450);
            this.textBox225.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox225.Multiline = true;
            this.textBox225.Name = "textBox225";
            this.textBox225.Size = new System.Drawing.Size(20, 24);
            this.textBox225.TabIndex = 428;
            this.textBox225.Text = " ";
            this.textBox225.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox210
            // 
            this.textBox210.Location = new System.Drawing.Point(845, 450);
            this.textBox210.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox210.Multiline = true;
            this.textBox210.Name = "textBox210";
            this.textBox210.Size = new System.Drawing.Size(24, 24);
            this.textBox210.TabIndex = 427;
            this.textBox210.Text = " ";
            this.textBox210.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox211
            // 
            this.textBox211.Location = new System.Drawing.Point(601, 450);
            this.textBox211.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox211.Multiline = true;
            this.textBox211.Name = "textBox211";
            this.textBox211.Size = new System.Drawing.Size(23, 24);
            this.textBox211.TabIndex = 426;
            this.textBox211.Text = "10.";
            this.textBox211.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox212
            // 
            this.textBox212.Location = new System.Drawing.Point(734, 383);
            this.textBox212.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox212.Multiline = true;
            this.textBox212.Name = "textBox212";
            this.textBox212.Size = new System.Drawing.Size(23, 24);
            this.textBox212.TabIndex = 425;
            this.textBox212.Text = " ";
            this.textBox212.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox213
            // 
            this.textBox213.Location = new System.Drawing.Point(709, 383);
            this.textBox213.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox213.Multiline = true;
            this.textBox213.Name = "textBox213";
            this.textBox213.Size = new System.Drawing.Size(23, 24);
            this.textBox213.TabIndex = 424;
            this.textBox213.Text = " ";
            this.textBox213.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox214
            // 
            this.textBox214.Location = new System.Drawing.Point(762, 383);
            this.textBox214.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox214.Multiline = true;
            this.textBox214.Name = "textBox214";
            this.textBox214.Size = new System.Drawing.Size(23, 24);
            this.textBox214.TabIndex = 423;
            this.textBox214.Text = " ";
            this.textBox214.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox215
            // 
            this.textBox215.Location = new System.Drawing.Point(789, 383);
            this.textBox215.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox215.Multiline = true;
            this.textBox215.Name = "textBox215";
            this.textBox215.Size = new System.Drawing.Size(23, 24);
            this.textBox215.TabIndex = 422;
            this.textBox215.Text = " ";
            this.textBox215.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox216
            // 
            this.textBox216.Location = new System.Drawing.Point(654, 383);
            this.textBox216.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox216.Multiline = true;
            this.textBox216.Name = "textBox216";
            this.textBox216.Size = new System.Drawing.Size(23, 24);
            this.textBox216.TabIndex = 421;
            this.textBox216.Text = " ";
            this.textBox216.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox217
            // 
            this.textBox217.Location = new System.Drawing.Point(599, 383);
            this.textBox217.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox217.Multiline = true;
            this.textBox217.Name = "textBox217";
            this.textBox217.Size = new System.Drawing.Size(23, 24);
            this.textBox217.TabIndex = 420;
            this.textBox217.Text = "8.";
            this.textBox217.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox218
            // 
            this.textBox218.Location = new System.Drawing.Point(681, 383);
            this.textBox218.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox218.Multiline = true;
            this.textBox218.Name = "textBox218";
            this.textBox218.Size = new System.Drawing.Size(23, 24);
            this.textBox218.TabIndex = 419;
            this.textBox218.Text = " ";
            this.textBox218.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox199
            // 
            this.textBox199.Location = new System.Drawing.Point(601, 877);
            this.textBox199.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox199.Multiline = true;
            this.textBox199.Name = "textBox199";
            this.textBox199.Size = new System.Drawing.Size(20, 24);
            this.textBox199.TabIndex = 418;
            this.textBox199.Text = " ";
            this.textBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox200
            // 
            this.textBox200.BackColor = System.Drawing.SystemColors.Window;
            this.textBox200.Location = new System.Drawing.Point(548, 877);
            this.textBox200.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox200.Multiline = true;
            this.textBox200.Name = "textBox200";
            this.textBox200.Size = new System.Drawing.Size(23, 24);
            this.textBox200.TabIndex = 417;
            this.textBox200.Text = " ";
            this.textBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox201
            // 
            this.textBox201.BackColor = System.Drawing.SystemColors.Window;
            this.textBox201.Location = new System.Drawing.Point(521, 877);
            this.textBox201.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox201.Multiline = true;
            this.textBox201.Name = "textBox201";
            this.textBox201.Size = new System.Drawing.Size(23, 24);
            this.textBox201.TabIndex = 416;
            this.textBox201.Text = " ";
            this.textBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox202
            // 
            this.textBox202.BackColor = System.Drawing.SystemColors.Window;
            this.textBox202.Location = new System.Drawing.Point(438, 877);
            this.textBox202.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox202.Multiline = true;
            this.textBox202.Name = "textBox202";
            this.textBox202.Size = new System.Drawing.Size(23, 24);
            this.textBox202.TabIndex = 415;
            this.textBox202.Text = " ";
            this.textBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox203
            // 
            this.textBox203.BackColor = System.Drawing.SystemColors.Window;
            this.textBox203.Location = new System.Drawing.Point(411, 877);
            this.textBox203.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox203.Multiline = true;
            this.textBox203.Name = "textBox203";
            this.textBox203.Size = new System.Drawing.Size(23, 24);
            this.textBox203.TabIndex = 414;
            this.textBox203.Text = " ";
            this.textBox203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox204
            // 
            this.textBox204.BackColor = System.Drawing.SystemColors.Window;
            this.textBox204.Location = new System.Drawing.Point(466, 877);
            this.textBox204.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox204.Multiline = true;
            this.textBox204.Name = "textBox204";
            this.textBox204.Size = new System.Drawing.Size(23, 24);
            this.textBox204.TabIndex = 413;
            this.textBox204.Text = " ";
            this.textBox204.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox205
            // 
            this.textBox205.BackColor = System.Drawing.SystemColors.Window;
            this.textBox205.Location = new System.Drawing.Point(493, 877);
            this.textBox205.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox205.Multiline = true;
            this.textBox205.Name = "textBox205";
            this.textBox205.Size = new System.Drawing.Size(23, 24);
            this.textBox205.TabIndex = 412;
            this.textBox205.Text = " ";
            this.textBox205.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox206
            // 
            this.textBox206.BackColor = System.Drawing.SystemColors.Window;
            this.textBox206.Location = new System.Drawing.Point(356, 877);
            this.textBox206.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox206.Multiline = true;
            this.textBox206.Name = "textBox206";
            this.textBox206.Size = new System.Drawing.Size(23, 24);
            this.textBox206.TabIndex = 411;
            this.textBox206.Text = " ";
            this.textBox206.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox207
            // 
            this.textBox207.Location = new System.Drawing.Point(329, 877);
            this.textBox207.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox207.Multiline = true;
            this.textBox207.Name = "textBox207";
            this.textBox207.Size = new System.Drawing.Size(23, 24);
            this.textBox207.TabIndex = 410;
            this.textBox207.Text = "5.";
            this.textBox207.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox208
            // 
            this.textBox208.Location = new System.Drawing.Point(682, 877);
            this.textBox208.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox208.Multiline = true;
            this.textBox208.Name = "textBox208";
            this.textBox208.Size = new System.Drawing.Size(20, 24);
            this.textBox208.TabIndex = 409;
            this.textBox208.Text = " ";
            this.textBox208.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox209
            // 
            this.textBox209.BackColor = System.Drawing.SystemColors.Window;
            this.textBox209.Location = new System.Drawing.Point(383, 877);
            this.textBox209.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox209.Multiline = true;
            this.textBox209.Name = "textBox209";
            this.textBox209.Size = new System.Drawing.Size(23, 24);
            this.textBox209.TabIndex = 408;
            this.textBox209.Text = " ";
            this.textBox209.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox188
            // 
            this.textBox188.Location = new System.Drawing.Point(626, 813);
            this.textBox188.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox188.Multiline = true;
            this.textBox188.Name = "textBox188";
            this.textBox188.Size = new System.Drawing.Size(20, 24);
            this.textBox188.TabIndex = 407;
            this.textBox188.Text = " ";
            this.textBox188.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox189
            // 
            this.textBox189.Location = new System.Drawing.Point(654, 877);
            this.textBox189.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox189.Multiline = true;
            this.textBox189.Name = "textBox189";
            this.textBox189.Size = new System.Drawing.Size(20, 24);
            this.textBox189.TabIndex = 406;
            this.textBox189.Text = " ";
            this.textBox189.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox190
            // 
            this.textBox190.Location = new System.Drawing.Point(627, 750);
            this.textBox190.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox190.Multiline = true;
            this.textBox190.Name = "textBox190";
            this.textBox190.Size = new System.Drawing.Size(20, 24);
            this.textBox190.TabIndex = 405;
            this.textBox190.Text = " ";
            this.textBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox191
            // 
            this.textBox191.Location = new System.Drawing.Point(627, 718);
            this.textBox191.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox191.Multiline = true;
            this.textBox191.Name = "textBox191";
            this.textBox191.Size = new System.Drawing.Size(20, 24);
            this.textBox191.TabIndex = 404;
            this.textBox191.Text = " ";
            this.textBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox192
            // 
            this.textBox192.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox192.Location = new System.Drawing.Point(575, 877);
            this.textBox192.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox192.Multiline = true;
            this.textBox192.Name = "textBox192";
            this.textBox192.Size = new System.Drawing.Size(20, 24);
            this.textBox192.TabIndex = 403;
            this.textBox192.Text = " ";
            this.textBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox193
            // 
            this.textBox193.Location = new System.Drawing.Point(624, 686);
            this.textBox193.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox193.Multiline = true;
            this.textBox193.Name = "textBox193";
            this.textBox193.Size = new System.Drawing.Size(20, 24);
            this.textBox193.TabIndex = 402;
            this.textBox193.Text = " ";
            this.textBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox194
            // 
            this.textBox194.Location = new System.Drawing.Point(624, 645);
            this.textBox194.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox194.Multiline = true;
            this.textBox194.Name = "textBox194";
            this.textBox194.Size = new System.Drawing.Size(20, 24);
            this.textBox194.TabIndex = 401;
            this.textBox194.Text = " ";
            this.textBox194.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox195
            // 
            this.textBox195.Location = new System.Drawing.Point(626, 845);
            this.textBox195.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox195.Multiline = true;
            this.textBox195.Name = "textBox195";
            this.textBox195.Size = new System.Drawing.Size(20, 24);
            this.textBox195.TabIndex = 400;
            this.textBox195.Text = " ";
            this.textBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox196
            // 
            this.textBox196.Location = new System.Drawing.Point(624, 544);
            this.textBox196.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox196.Multiline = true;
            this.textBox196.Name = "textBox196";
            this.textBox196.Size = new System.Drawing.Size(29, 24);
            this.textBox196.TabIndex = 399;
            this.textBox196.Text = "14.";
            this.textBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox197
            // 
            this.textBox197.Location = new System.Drawing.Point(627, 581);
            this.textBox197.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox197.Multiline = true;
            this.textBox197.Name = "textBox197";
            this.textBox197.Size = new System.Drawing.Size(20, 24);
            this.textBox197.TabIndex = 398;
            this.textBox197.Text = " ";
            this.textBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox198
            // 
            this.textBox198.Location = new System.Drawing.Point(626, 613);
            this.textBox198.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox198.Multiline = true;
            this.textBox198.Name = "textBox198";
            this.textBox198.Size = new System.Drawing.Size(20, 24);
            this.textBox198.TabIndex = 397;
            this.textBox198.Text = " ";
            this.textBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox176
            // 
            this.textBox176.Location = new System.Drawing.Point(627, 877);
            this.textBox176.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox176.Multiline = true;
            this.textBox176.Name = "textBox176";
            this.textBox176.Size = new System.Drawing.Size(20, 24);
            this.textBox176.TabIndex = 396;
            this.textBox176.Text = " ";
            this.textBox176.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox177
            // 
            this.textBox177.Location = new System.Drawing.Point(764, 781);
            this.textBox177.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox177.Multiline = true;
            this.textBox177.Name = "textBox177";
            this.textBox177.Size = new System.Drawing.Size(20, 24);
            this.textBox177.TabIndex = 395;
            this.textBox177.Text = " ";
            this.textBox177.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox178
            // 
            this.textBox178.Location = new System.Drawing.Point(737, 781);
            this.textBox178.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox178.Multiline = true;
            this.textBox178.Name = "textBox178";
            this.textBox178.Size = new System.Drawing.Size(20, 24);
            this.textBox178.TabIndex = 394;
            this.textBox178.Text = " ";
            this.textBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox179
            // 
            this.textBox179.Location = new System.Drawing.Point(710, 781);
            this.textBox179.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox179.Multiline = true;
            this.textBox179.Name = "textBox179";
            this.textBox179.Size = new System.Drawing.Size(20, 24);
            this.textBox179.TabIndex = 393;
            this.textBox179.Text = " ";
            this.textBox179.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox180
            // 
            this.textBox180.Location = new System.Drawing.Point(682, 781);
            this.textBox180.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox180.Multiline = true;
            this.textBox180.Name = "textBox180";
            this.textBox180.Size = new System.Drawing.Size(20, 24);
            this.textBox180.TabIndex = 392;
            this.textBox180.Text = " ";
            this.textBox180.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox181
            // 
            this.textBox181.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox181.Location = new System.Drawing.Point(655, 781);
            this.textBox181.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox181.Multiline = true;
            this.textBox181.Name = "textBox181";
            this.textBox181.Size = new System.Drawing.Size(20, 24);
            this.textBox181.TabIndex = 391;
            this.textBox181.Text = " ";
            this.textBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox182
            // 
            this.textBox182.Location = new System.Drawing.Point(627, 781);
            this.textBox182.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox182.Multiline = true;
            this.textBox182.Name = "textBox182";
            this.textBox182.Size = new System.Drawing.Size(20, 24);
            this.textBox182.TabIndex = 390;
            this.textBox182.Text = " ";
            this.textBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox183
            // 
            this.textBox183.Location = new System.Drawing.Point(597, 781);
            this.textBox183.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox183.Multiline = true;
            this.textBox183.Name = "textBox183";
            this.textBox183.Size = new System.Drawing.Size(20, 24);
            this.textBox183.TabIndex = 389;
            this.textBox183.Text = " ";
            this.textBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox184
            // 
            this.textBox184.Location = new System.Drawing.Point(792, 781);
            this.textBox184.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox184.Multiline = true;
            this.textBox184.Name = "textBox184";
            this.textBox184.Size = new System.Drawing.Size(20, 24);
            this.textBox184.TabIndex = 388;
            this.textBox184.Text = " ";
            this.textBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox185
            // 
            this.textBox185.Location = new System.Drawing.Point(508, 781);
            this.textBox185.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox185.Multiline = true;
            this.textBox185.Name = "textBox185";
            this.textBox185.Size = new System.Drawing.Size(29, 24);
            this.textBox185.TabIndex = 387;
            this.textBox185.Text = "15.";
            this.textBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox186
            // 
            this.textBox186.Location = new System.Drawing.Point(545, 781);
            this.textBox186.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox186.Multiline = true;
            this.textBox186.Name = "textBox186";
            this.textBox186.Size = new System.Drawing.Size(20, 24);
            this.textBox186.TabIndex = 386;
            this.textBox186.Text = " ";
            this.textBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox187
            // 
            this.textBox187.Location = new System.Drawing.Point(626, 909);
            this.textBox187.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox187.Multiline = true;
            this.textBox187.Name = "textBox187";
            this.textBox187.Size = new System.Drawing.Size(20, 24);
            this.textBox187.TabIndex = 385;
            this.textBox187.Text = " ";
            this.textBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox175
            // 
            this.textBox175.Location = new System.Drawing.Point(597, 515);
            this.textBox175.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox175.Multiline = true;
            this.textBox175.Name = "textBox175";
            this.textBox175.Size = new System.Drawing.Size(20, 24);
            this.textBox175.TabIndex = 384;
            this.textBox175.Text = " ";
            this.textBox175.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox172
            // 
            this.textBox172.Location = new System.Drawing.Point(626, 482);
            this.textBox172.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox172.Multiline = true;
            this.textBox172.Name = "textBox172";
            this.textBox172.Size = new System.Drawing.Size(20, 24);
            this.textBox172.TabIndex = 383;
            this.textBox172.Text = " ";
            this.textBox172.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox173
            // 
            this.textBox173.Location = new System.Drawing.Point(626, 448);
            this.textBox173.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox173.Multiline = true;
            this.textBox173.Name = "textBox173";
            this.textBox173.Size = new System.Drawing.Size(20, 24);
            this.textBox173.TabIndex = 382;
            this.textBox173.Text = " ";
            this.textBox173.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox174
            // 
            this.textBox174.Location = new System.Drawing.Point(626, 416);
            this.textBox174.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox174.Multiline = true;
            this.textBox174.Name = "textBox174";
            this.textBox174.Size = new System.Drawing.Size(20, 24);
            this.textBox174.TabIndex = 381;
            this.textBox174.Text = " ";
            this.textBox174.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox171
            // 
            this.textBox171.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox171.Location = new System.Drawing.Point(626, 316);
            this.textBox171.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox171.Multiline = true;
            this.textBox171.Name = "textBox171";
            this.textBox171.Size = new System.Drawing.Size(20, 24);
            this.textBox171.TabIndex = 380;
            this.textBox171.Text = "a";
            this.textBox171.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox162
            // 
            this.textBox162.Location = new System.Drawing.Point(624, 20);
            this.textBox162.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox162.Multiline = true;
            this.textBox162.Name = "textBox162";
            this.textBox162.Size = new System.Drawing.Size(29, 24);
            this.textBox162.TabIndex = 379;
            this.textBox162.Text = "12.";
            this.textBox162.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox163
            // 
            this.textBox163.Location = new System.Drawing.Point(626, 88);
            this.textBox163.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox163.Multiline = true;
            this.textBox163.Name = "textBox163";
            this.textBox163.Size = new System.Drawing.Size(20, 24);
            this.textBox163.TabIndex = 378;
            this.textBox163.Text = " ";
            this.textBox163.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox164
            // 
            this.textBox164.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox164.Location = new System.Drawing.Point(626, 222);
            this.textBox164.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox164.Multiline = true;
            this.textBox164.Name = "textBox164";
            this.textBox164.Size = new System.Drawing.Size(20, 24);
            this.textBox164.TabIndex = 377;
            this.textBox164.Text = "13.";
            this.textBox164.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox165
            // 
            this.textBox165.Location = new System.Drawing.Point(626, 52);
            this.textBox165.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox165.Multiline = true;
            this.textBox165.Name = "textBox165";
            this.textBox165.Size = new System.Drawing.Size(20, 24);
            this.textBox165.TabIndex = 376;
            this.textBox165.Text = " ";
            this.textBox165.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox166
            // 
            this.textBox166.Location = new System.Drawing.Point(626, 348);
            this.textBox166.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox166.Multiline = true;
            this.textBox166.Name = "textBox166";
            this.textBox166.Size = new System.Drawing.Size(20, 24);
            this.textBox166.TabIndex = 375;
            this.textBox166.Text = " ";
            this.textBox166.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox167
            // 
            this.textBox167.Location = new System.Drawing.Point(626, 383);
            this.textBox167.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox167.Multiline = true;
            this.textBox167.Name = "textBox167";
            this.textBox167.Size = new System.Drawing.Size(20, 24);
            this.textBox167.TabIndex = 374;
            this.textBox167.Text = " ";
            this.textBox167.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox168
            // 
            this.textBox168.Location = new System.Drawing.Point(626, 254);
            this.textBox168.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox168.Multiline = true;
            this.textBox168.Name = "textBox168";
            this.textBox168.Size = new System.Drawing.Size(20, 24);
            this.textBox168.TabIndex = 373;
            this.textBox168.Text = " ";
            this.textBox168.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox169
            // 
            this.textBox169.Location = new System.Drawing.Point(626, 283);
            this.textBox169.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox169.Multiline = true;
            this.textBox169.Name = "textBox169";
            this.textBox169.Size = new System.Drawing.Size(20, 24);
            this.textBox169.TabIndex = 372;
            this.textBox169.Text = " ";
            this.textBox169.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox170
            // 
            this.textBox170.Location = new System.Drawing.Point(626, 155);
            this.textBox170.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox170.Multiline = true;
            this.textBox170.Name = "textBox170";
            this.textBox170.Size = new System.Drawing.Size(20, 24);
            this.textBox170.TabIndex = 371;
            this.textBox170.Text = " ";
            this.textBox170.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox153
            // 
            this.textBox153.Location = new System.Drawing.Point(544, 88);
            this.textBox153.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox153.Multiline = true;
            this.textBox153.Name = "textBox153";
            this.textBox153.Size = new System.Drawing.Size(20, 24);
            this.textBox153.TabIndex = 370;
            this.textBox153.Text = " ";
            this.textBox153.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox154
            // 
            this.textBox154.Location = new System.Drawing.Point(544, 155);
            this.textBox154.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox154.Multiline = true;
            this.textBox154.Name = "textBox154";
            this.textBox154.Size = new System.Drawing.Size(20, 24);
            this.textBox154.TabIndex = 369;
            this.textBox154.Text = " ";
            this.textBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox155
            // 
            this.textBox155.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox155.Location = new System.Drawing.Point(544, 227);
            this.textBox155.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox155.Multiline = true;
            this.textBox155.Name = "textBox155";
            this.textBox155.Size = new System.Drawing.Size(20, 24);
            this.textBox155.TabIndex = 368;
            this.textBox155.Text = "a";
            this.textBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox156
            // 
            this.textBox156.Location = new System.Drawing.Point(544, 188);
            this.textBox156.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox156.Multiline = true;
            this.textBox156.Name = "textBox156";
            this.textBox156.Size = new System.Drawing.Size(20, 24);
            this.textBox156.TabIndex = 367;
            this.textBox156.Text = " ";
            this.textBox156.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox157
            // 
            this.textBox157.Location = new System.Drawing.Point(544, 356);
            this.textBox157.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox157.Multiline = true;
            this.textBox157.Name = "textBox157";
            this.textBox157.Size = new System.Drawing.Size(20, 24);
            this.textBox157.TabIndex = 366;
            this.textBox157.Text = " ";
            this.textBox157.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox158
            // 
            this.textBox158.Location = new System.Drawing.Point(626, 188);
            this.textBox158.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox158.Multiline = true;
            this.textBox158.Name = "textBox158";
            this.textBox158.Size = new System.Drawing.Size(20, 24);
            this.textBox158.TabIndex = 365;
            this.textBox158.Text = " ";
            this.textBox158.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox159
            // 
            this.textBox159.Location = new System.Drawing.Point(544, 290);
            this.textBox159.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox159.Multiline = true;
            this.textBox159.Name = "textBox159";
            this.textBox159.Size = new System.Drawing.Size(20, 24);
            this.textBox159.TabIndex = 364;
            this.textBox159.Text = " ";
            this.textBox159.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox160
            // 
            this.textBox160.Location = new System.Drawing.Point(544, 323);
            this.textBox160.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox160.Multiline = true;
            this.textBox160.Name = "textBox160";
            this.textBox160.Size = new System.Drawing.Size(20, 24);
            this.textBox160.TabIndex = 363;
            this.textBox160.Text = " ";
            this.textBox160.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox161
            // 
            this.textBox161.Location = new System.Drawing.Point(544, 256);
            this.textBox161.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox161.Multiline = true;
            this.textBox161.Name = "textBox161";
            this.textBox161.Size = new System.Drawing.Size(20, 24);
            this.textBox161.TabIndex = 362;
            this.textBox161.Text = " ";
            this.textBox161.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox141
            // 
            this.textBox141.Location = new System.Drawing.Point(462, 122);
            this.textBox141.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox141.Multiline = true;
            this.textBox141.Name = "textBox141";
            this.textBox141.Size = new System.Drawing.Size(20, 24);
            this.textBox141.TabIndex = 361;
            this.textBox141.Text = " ";
            this.textBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox142
            // 
            this.textBox142.Location = new System.Drawing.Point(489, 122);
            this.textBox142.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox142.Multiline = true;
            this.textBox142.Name = "textBox142";
            this.textBox142.Size = new System.Drawing.Size(20, 24);
            this.textBox142.TabIndex = 360;
            this.textBox142.Text = " ";
            this.textBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox144
            // 
            this.textBox144.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox144.Location = new System.Drawing.Point(599, 122);
            this.textBox144.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox144.Multiline = true;
            this.textBox144.Name = "textBox144";
            this.textBox144.Size = new System.Drawing.Size(20, 24);
            this.textBox144.TabIndex = 359;
            this.textBox144.Text = "s";
            this.textBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox147
            // 
            this.textBox147.Location = new System.Drawing.Point(517, 122);
            this.textBox147.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox147.Multiline = true;
            this.textBox147.Name = "textBox147";
            this.textBox147.Size = new System.Drawing.Size(20, 24);
            this.textBox147.TabIndex = 358;
            this.textBox147.Text = " ";
            this.textBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox148
            // 
            this.textBox148.Location = new System.Drawing.Point(654, 122);
            this.textBox148.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox148.Multiline = true;
            this.textBox148.Name = "textBox148";
            this.textBox148.Size = new System.Drawing.Size(20, 24);
            this.textBox148.TabIndex = 357;
            this.textBox148.Text = " ";
            this.textBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox149
            // 
            this.textBox149.Location = new System.Drawing.Point(681, 122);
            this.textBox149.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox149.Multiline = true;
            this.textBox149.Name = "textBox149";
            this.textBox149.Size = new System.Drawing.Size(20, 24);
            this.textBox149.TabIndex = 356;
            this.textBox149.Text = " ";
            this.textBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox150
            // 
            this.textBox150.Location = new System.Drawing.Point(571, 122);
            this.textBox150.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox150.Multiline = true;
            this.textBox150.Name = "textBox150";
            this.textBox150.Size = new System.Drawing.Size(20, 24);
            this.textBox150.TabIndex = 355;
            this.textBox150.Text = " ";
            this.textBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox151
            // 
            this.textBox151.Location = new System.Drawing.Point(626, 122);
            this.textBox151.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox151.Multiline = true;
            this.textBox151.Name = "textBox151";
            this.textBox151.Size = new System.Drawing.Size(20, 24);
            this.textBox151.TabIndex = 354;
            this.textBox151.Text = " ";
            this.textBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox152
            // 
            this.textBox152.Location = new System.Drawing.Point(544, 122);
            this.textBox152.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox152.Multiline = true;
            this.textBox152.Name = "textBox152";
            this.textBox152.Size = new System.Drawing.Size(20, 24);
            this.textBox152.TabIndex = 353;
            this.textBox152.Text = " ";
            this.textBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox139
            // 
            this.textBox139.Location = new System.Drawing.Point(434, 88);
            this.textBox139.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox139.Multiline = true;
            this.textBox139.Name = "textBox139";
            this.textBox139.Size = new System.Drawing.Size(20, 24);
            this.textBox139.TabIndex = 352;
            this.textBox139.Text = "7.";
            this.textBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox137
            // 
            this.textBox137.Location = new System.Drawing.Point(435, 122);
            this.textBox137.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox137.Multiline = true;
            this.textBox137.Name = "textBox137";
            this.textBox137.Size = new System.Drawing.Size(20, 24);
            this.textBox137.TabIndex = 351;
            this.textBox137.Text = " ";
            this.textBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox136
            // 
            this.textBox136.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox136.Location = new System.Drawing.Point(435, 250);
            this.textBox136.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox136.Multiline = true;
            this.textBox136.Name = "textBox136";
            this.textBox136.Size = new System.Drawing.Size(20, 24);
            this.textBox136.TabIndex = 350;
            this.textBox136.Text = " ";
            this.textBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox138
            // 
            this.textBox138.Location = new System.Drawing.Point(435, 155);
            this.textBox138.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox138.Multiline = true;
            this.textBox138.Name = "textBox138";
            this.textBox138.Size = new System.Drawing.Size(20, 24);
            this.textBox138.TabIndex = 348;
            this.textBox138.Text = " ";
            this.textBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox140
            // 
            this.textBox140.Location = new System.Drawing.Point(435, 316);
            this.textBox140.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox140.Multiline = true;
            this.textBox140.Name = "textBox140";
            this.textBox140.Size = new System.Drawing.Size(20, 24);
            this.textBox140.TabIndex = 346;
            this.textBox140.Text = " ";
            this.textBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox143
            // 
            this.textBox143.Location = new System.Drawing.Point(434, 346);
            this.textBox143.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox143.Multiline = true;
            this.textBox143.Name = "textBox143";
            this.textBox143.Size = new System.Drawing.Size(20, 24);
            this.textBox143.TabIndex = 343;
            this.textBox143.Text = " ";
            this.textBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox145
            // 
            this.textBox145.Location = new System.Drawing.Point(434, 216);
            this.textBox145.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox145.Multiline = true;
            this.textBox145.Name = "textBox145";
            this.textBox145.Size = new System.Drawing.Size(20, 24);
            this.textBox145.TabIndex = 341;
            this.textBox145.Text = " ";
            this.textBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox146
            // 
            this.textBox146.Location = new System.Drawing.Point(434, 283);
            this.textBox146.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox146.Multiline = true;
            this.textBox146.Name = "textBox146";
            this.textBox146.Size = new System.Drawing.Size(20, 24);
            this.textBox146.TabIndex = 340;
            this.textBox146.Text = " ";
            this.textBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox101
            // 
            this.textBox101.Location = new System.Drawing.Point(434, 718);
            this.textBox101.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox101.Multiline = true;
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(20, 24);
            this.textBox101.TabIndex = 339;
            this.textBox101.Text = " ";
            this.textBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox117
            // 
            this.textBox117.Location = new System.Drawing.Point(379, 718);
            this.textBox117.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox117.Multiline = true;
            this.textBox117.Name = "textBox117";
            this.textBox117.Size = new System.Drawing.Size(20, 24);
            this.textBox117.TabIndex = 338;
            this.textBox117.Text = " ";
            this.textBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox123
            // 
            this.textBox123.Location = new System.Drawing.Point(352, 718);
            this.textBox123.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox123.Multiline = true;
            this.textBox123.Name = "textBox123";
            this.textBox123.Size = new System.Drawing.Size(20, 24);
            this.textBox123.TabIndex = 337;
            this.textBox123.Text = " ";
            this.textBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox127
            // 
            this.textBox127.Location = new System.Drawing.Point(325, 718);
            this.textBox127.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox127.Multiline = true;
            this.textBox127.Name = "textBox127";
            this.textBox127.Size = new System.Drawing.Size(20, 24);
            this.textBox127.TabIndex = 336;
            this.textBox127.Text = " ";
            this.textBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox129
            // 
            this.textBox129.Location = new System.Drawing.Point(297, 718);
            this.textBox129.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox129.Multiline = true;
            this.textBox129.Name = "textBox129";
            this.textBox129.Size = new System.Drawing.Size(20, 24);
            this.textBox129.TabIndex = 335;
            this.textBox129.Text = " ";
            this.textBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox130
            // 
            this.textBox130.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox130.Location = new System.Drawing.Point(270, 718);
            this.textBox130.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox130.Multiline = true;
            this.textBox130.Name = "textBox130";
            this.textBox130.Size = new System.Drawing.Size(20, 24);
            this.textBox130.TabIndex = 334;
            this.textBox130.Text = " ";
            this.textBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox131
            // 
            this.textBox131.Location = new System.Drawing.Point(242, 718);
            this.textBox131.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox131.Multiline = true;
            this.textBox131.Name = "textBox131";
            this.textBox131.Size = new System.Drawing.Size(20, 24);
            this.textBox131.TabIndex = 333;
            this.textBox131.Text = " ";
            this.textBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox132
            // 
            this.textBox132.BackColor = System.Drawing.SystemColors.Window;
            this.textBox132.Location = new System.Drawing.Point(215, 718);
            this.textBox132.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox132.Multiline = true;
            this.textBox132.Name = "textBox132";
            this.textBox132.Size = new System.Drawing.Size(20, 24);
            this.textBox132.TabIndex = 332;
            this.textBox132.Text = " ";
            this.textBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox133
            // 
            this.textBox133.Location = new System.Drawing.Point(434, 188);
            this.textBox133.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox133.Multiline = true;
            this.textBox133.Name = "textBox133";
            this.textBox133.Size = new System.Drawing.Size(20, 24);
            this.textBox133.TabIndex = 331;
            this.textBox133.Text = " ";
            this.textBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox134
            // 
            this.textBox134.Location = new System.Drawing.Point(407, 718);
            this.textBox134.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox134.Multiline = true;
            this.textBox134.Name = "textBox134";
            this.textBox134.Size = new System.Drawing.Size(20, 24);
            this.textBox134.TabIndex = 330;
            this.textBox134.Text = " ";
            this.textBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox135
            // 
            this.textBox135.Location = new System.Drawing.Point(118, 718);
            this.textBox135.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox135.Multiline = true;
            this.textBox135.Name = "textBox135";
            this.textBox135.Size = new System.Drawing.Size(35, 24);
            this.textBox135.TabIndex = 329;
            this.textBox135.Text = "14.";
            this.textBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(379, 781);
            this.textBox68.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox68.Multiline = true;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(20, 24);
            this.textBox68.TabIndex = 328;
            this.textBox68.Text = " ";
            this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox96
            // 
            this.textBox96.Location = new System.Drawing.Point(352, 781);
            this.textBox96.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox96.Multiline = true;
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(20, 24);
            this.textBox96.TabIndex = 327;
            this.textBox96.Text = " ";
            this.textBox96.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox97
            // 
            this.textBox97.Location = new System.Drawing.Point(325, 781);
            this.textBox97.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox97.Multiline = true;
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(20, 24);
            this.textBox97.TabIndex = 326;
            this.textBox97.Text = " ";
            this.textBox97.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox98
            // 
            this.textBox98.Location = new System.Drawing.Point(242, 781);
            this.textBox98.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox98.Multiline = true;
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(20, 24);
            this.textBox98.TabIndex = 325;
            this.textBox98.Text = " ";
            this.textBox98.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox99
            // 
            this.textBox99.BackColor = System.Drawing.SystemColors.Window;
            this.textBox99.Location = new System.Drawing.Point(160, 718);
            this.textBox99.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox99.Multiline = true;
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(20, 24);
            this.textBox99.TabIndex = 324;
            this.textBox99.Text = " ";
            this.textBox99.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox100
            // 
            this.textBox100.BackColor = System.Drawing.SystemColors.Window;
            this.textBox100.Location = new System.Drawing.Point(215, 781);
            this.textBox100.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox100.Multiline = true;
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(20, 24);
            this.textBox100.TabIndex = 323;
            this.textBox100.Text = " ";
            this.textBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox102
            // 
            this.textBox102.Location = new System.Drawing.Point(270, 781);
            this.textBox102.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox102.Multiline = true;
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(20, 24);
            this.textBox102.TabIndex = 321;
            this.textBox102.Text = " ";
            this.textBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox103
            // 
            this.textBox103.Location = new System.Drawing.Point(297, 781);
            this.textBox103.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox103.Multiline = true;
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(20, 24);
            this.textBox103.TabIndex = 320;
            this.textBox103.Text = " ";
            this.textBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox104
            // 
            this.textBox104.BackColor = System.Drawing.SystemColors.Window;
            this.textBox104.Location = new System.Drawing.Point(160, 781);
            this.textBox104.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox104.Multiline = true;
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(20, 24);
            this.textBox104.TabIndex = 319;
            this.textBox104.Text = " ";
            this.textBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox105
            // 
            this.textBox105.Location = new System.Drawing.Point(133, 781);
            this.textBox105.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox105.Multiline = true;
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(20, 24);
            this.textBox105.TabIndex = 318;
            this.textBox105.Text = "7.";
            this.textBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(407, 781);
            this.textBox69.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox69.Multiline = true;
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(20, 24);
            this.textBox69.TabIndex = 317;
            this.textBox69.Text = " ";
            this.textBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(187, 482);
            this.textBox70.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox70.Multiline = true;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(20, 24);
            this.textBox70.TabIndex = 316;
            this.textBox70.Text = "3.";
            this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox71
            // 
            this.textBox71.BackColor = System.Drawing.SystemColors.Window;
            this.textBox71.Location = new System.Drawing.Point(187, 781);
            this.textBox71.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox71.Multiline = true;
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(20, 24);
            this.textBox71.TabIndex = 315;
            this.textBox71.Text = " ";
            this.textBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox72
            // 
            this.textBox72.BackColor = System.Drawing.SystemColors.Window;
            this.textBox72.Location = new System.Drawing.Point(187, 747);
            this.textBox72.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox72.Multiline = true;
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(20, 24);
            this.textBox72.TabIndex = 314;
            this.textBox72.Text = " ";
            this.textBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox73
            // 
            this.textBox73.BackColor = System.Drawing.SystemColors.Window;
            this.textBox73.Location = new System.Drawing.Point(187, 718);
            this.textBox73.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox73.Multiline = true;
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(20, 24);
            this.textBox73.TabIndex = 313;
            this.textBox73.Text = " ";
            this.textBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox74
            // 
            this.textBox74.BackColor = System.Drawing.SystemColors.Window;
            this.textBox74.Location = new System.Drawing.Point(187, 684);
            this.textBox74.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox74.Multiline = true;
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(20, 24);
            this.textBox74.TabIndex = 312;
            this.textBox74.Text = " ";
            this.textBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox83
            // 
            this.textBox83.BackColor = System.Drawing.SystemColors.Window;
            this.textBox83.Location = new System.Drawing.Point(187, 648);
            this.textBox83.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox83.Multiline = true;
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(20, 24);
            this.textBox83.TabIndex = 311;
            this.textBox83.Text = " ";
            this.textBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox93
            // 
            this.textBox93.BackColor = System.Drawing.SystemColors.Window;
            this.textBox93.Location = new System.Drawing.Point(187, 615);
            this.textBox93.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox93.Multiline = true;
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(20, 24);
            this.textBox93.TabIndex = 310;
            this.textBox93.Text = " ";
            this.textBox93.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox94
            // 
            this.textBox94.BackColor = System.Drawing.SystemColors.Window;
            this.textBox94.Location = new System.Drawing.Point(187, 582);
            this.textBox94.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox94.Multiline = true;
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(20, 24);
            this.textBox94.TabIndex = 309;
            this.textBox94.Text = " ";
            this.textBox94.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox95
            // 
            this.textBox95.BackColor = System.Drawing.SystemColors.Window;
            this.textBox95.Location = new System.Drawing.Point(187, 515);
            this.textBox95.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox95.Multiline = true;
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(20, 24);
            this.textBox95.TabIndex = 308;
            this.textBox95.Text = " ";
            this.textBox95.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(270, 644);
            this.textBox66.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox66.Multiline = true;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(20, 24);
            this.textBox66.TabIndex = 307;
            this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(270, 611);
            this.textBox65.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox65.Multiline = true;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(20, 24);
            this.textBox65.TabIndex = 306;
            this.textBox65.Text = " ";
            this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(270, 578);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(20, 24);
            this.textBox10.TabIndex = 305;
            this.textBox10.Text = " ";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(270, 511);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(20, 24);
            this.textBox9.TabIndex = 304;
            this.textBox9.Text = " ";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(270, 479);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(20, 24);
            this.textBox8.TabIndex = 303;
            this.textBox8.Text = " ";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(270, 446);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(20, 24);
            this.textBox7.TabIndex = 302;
            this.textBox7.Text = " ";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(270, 412);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(20, 24);
            this.textBox6.TabIndex = 301;
            this.textBox6.Text = "6.";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(571, 348);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(20, 24);
            this.textBox5.TabIndex = 300;
            this.textBox5.Text = "9.";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(571, 382);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(20, 24);
            this.textBox4.TabIndex = 299;
            this.textBox4.Text = " ";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(571, 415);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(20, 24);
            this.textBox3.TabIndex = 298;
            this.textBox3.Text = " ";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(571, 448);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(20, 24);
            this.textBox2.TabIndex = 297;
            this.textBox2.Text = " ";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(571, 482);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(20, 24);
            this.textBox1.TabIndex = 296;
            this.textBox1.Text = " ";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox128
            // 
            this.textBox128.Location = new System.Drawing.Point(571, 781);
            this.textBox128.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox128.Multiline = true;
            this.textBox128.Name = "textBox128";
            this.textBox128.Size = new System.Drawing.Size(20, 24);
            this.textBox128.TabIndex = 294;
            this.textBox128.Text = " ";
            this.textBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox126
            // 
            this.textBox126.Location = new System.Drawing.Point(571, 747);
            this.textBox126.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox126.Multiline = true;
            this.textBox126.Name = "textBox126";
            this.textBox126.Size = new System.Drawing.Size(20, 24);
            this.textBox126.TabIndex = 295;
            this.textBox126.Text = " ";
            this.textBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox125
            // 
            this.textBox125.Location = new System.Drawing.Point(571, 715);
            this.textBox125.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox125.Multiline = true;
            this.textBox125.Name = "textBox125";
            this.textBox125.Size = new System.Drawing.Size(20, 24);
            this.textBox125.TabIndex = 293;
            this.textBox125.Text = " ";
            this.textBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox124
            // 
            this.textBox124.Location = new System.Drawing.Point(571, 682);
            this.textBox124.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox124.Multiline = true;
            this.textBox124.Name = "textBox124";
            this.textBox124.Size = new System.Drawing.Size(20, 24);
            this.textBox124.TabIndex = 292;
            this.textBox124.Text = " ";
            this.textBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(462, 747);
            this.textBox79.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox79.Multiline = true;
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(20, 24);
            this.textBox79.TabIndex = 291;
            this.textBox79.Text = " ";
            this.textBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(462, 718);
            this.textBox78.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox78.Multiline = true;
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(20, 24);
            this.textBox78.TabIndex = 290;
            this.textBox78.Text = " ";
            this.textBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(462, 682);
            this.textBox77.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox77.Multiline = true;
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(20, 24);
            this.textBox77.TabIndex = 289;
            this.textBox77.Text = " ";
            this.textBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox122
            // 
            this.textBox122.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox122.Location = new System.Drawing.Point(571, 644);
            this.textBox122.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox122.Multiline = true;
            this.textBox122.Name = "textBox122";
            this.textBox122.Size = new System.Drawing.Size(20, 24);
            this.textBox122.TabIndex = 285;
            this.textBox122.Text = " ";
            this.textBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox121
            // 
            this.textBox121.Location = new System.Drawing.Point(571, 611);
            this.textBox121.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox121.Multiline = true;
            this.textBox121.Name = "textBox121";
            this.textBox121.Size = new System.Drawing.Size(20, 24);
            this.textBox121.TabIndex = 284;
            this.textBox121.Text = " ";
            this.textBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox120
            // 
            this.textBox120.Location = new System.Drawing.Point(571, 578);
            this.textBox120.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox120.Multiline = true;
            this.textBox120.Name = "textBox120";
            this.textBox120.Size = new System.Drawing.Size(20, 24);
            this.textBox120.TabIndex = 283;
            this.textBox120.Text = " ";
            this.textBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox119
            // 
            this.textBox119.Location = new System.Drawing.Point(571, 544);
            this.textBox119.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox119.Multiline = true;
            this.textBox119.Name = "textBox119";
            this.textBox119.Size = new System.Drawing.Size(20, 24);
            this.textBox119.TabIndex = 282;
            this.textBox119.Text = " ";
            this.textBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox118
            // 
            this.textBox118.Location = new System.Drawing.Point(544, 52);
            this.textBox118.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox118.Multiline = true;
            this.textBox118.Name = "textBox118";
            this.textBox118.Size = new System.Drawing.Size(20, 24);
            this.textBox118.TabIndex = 281;
            this.textBox118.Text = "8.";
            this.textBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox116
            // 
            this.textBox116.Location = new System.Drawing.Point(571, 515);
            this.textBox116.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox116.Multiline = true;
            this.textBox116.Name = "textBox116";
            this.textBox116.Size = new System.Drawing.Size(20, 24);
            this.textBox116.TabIndex = 280;
            this.textBox116.Text = " ";
            this.textBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox116.TextChanged += new System.EventHandler(this.textBox116_TextChanged);
            // 
            // textBox115
            // 
            this.textBox115.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox115.Location = new System.Drawing.Point(544, 515);
            this.textBox115.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox115.Multiline = true;
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(20, 24);
            this.textBox115.TabIndex = 279;
            this.textBox115.Text = " ";
            this.textBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox114
            // 
            this.textBox114.Location = new System.Drawing.Point(517, 515);
            this.textBox114.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox114.Multiline = true;
            this.textBox114.Name = "textBox114";
            this.textBox114.Size = new System.Drawing.Size(20, 24);
            this.textBox114.TabIndex = 278;
            this.textBox114.Text = " ";
            this.textBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox113
            // 
            this.textBox113.Location = new System.Drawing.Point(489, 515);
            this.textBox113.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox113.Multiline = true;
            this.textBox113.Name = "textBox113";
            this.textBox113.Size = new System.Drawing.Size(20, 24);
            this.textBox113.TabIndex = 277;
            this.textBox113.Text = " ";
            this.textBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox112
            // 
            this.textBox112.Location = new System.Drawing.Point(434, 515);
            this.textBox112.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox112.Multiline = true;
            this.textBox112.Name = "textBox112";
            this.textBox112.Size = new System.Drawing.Size(20, 24);
            this.textBox112.TabIndex = 276;
            this.textBox112.Text = "4.";
            this.textBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox111
            // 
            this.textBox111.Location = new System.Drawing.Point(379, 544);
            this.textBox111.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox111.Multiline = true;
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(20, 24);
            this.textBox111.TabIndex = 275;
            this.textBox111.Text = " ";
            this.textBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox110
            // 
            this.textBox110.Location = new System.Drawing.Point(352, 544);
            this.textBox110.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox110.Multiline = true;
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(20, 24);
            this.textBox110.TabIndex = 274;
            this.textBox110.Text = " ";
            this.textBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox109
            // 
            this.textBox109.Location = new System.Drawing.Point(325, 544);
            this.textBox109.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox109.Multiline = true;
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new System.Drawing.Size(20, 24);
            this.textBox109.TabIndex = 273;
            this.textBox109.Text = " ";
            this.textBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox108
            // 
            this.textBox108.Location = new System.Drawing.Point(297, 544);
            this.textBox108.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox108.Multiline = true;
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new System.Drawing.Size(20, 24);
            this.textBox108.TabIndex = 272;
            this.textBox108.Text = " ";
            this.textBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox107
            // 
            this.textBox107.Location = new System.Drawing.Point(270, 544);
            this.textBox107.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox107.Multiline = true;
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(20, 24);
            this.textBox107.TabIndex = 271;
            this.textBox107.Text = " ";
            this.textBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox106
            // 
            this.textBox106.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox106.Location = new System.Drawing.Point(242, 544);
            this.textBox106.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox106.Multiline = true;
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(20, 24);
            this.textBox106.TabIndex = 270;
            this.textBox106.Text = " ";
            this.textBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox92
            // 
            this.textBox92.BackColor = System.Drawing.SystemColors.Window;
            this.textBox92.Location = new System.Drawing.Point(215, 544);
            this.textBox92.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox92.Multiline = true;
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(20, 24);
            this.textBox92.TabIndex = 269;
            this.textBox92.Text = " ";
            this.textBox92.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox91
            // 
            this.textBox91.BackColor = System.Drawing.SystemColors.Window;
            this.textBox91.Location = new System.Drawing.Point(187, 544);
            this.textBox91.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox91.Multiline = true;
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(20, 24);
            this.textBox91.TabIndex = 268;
            this.textBox91.Text = " ";
            this.textBox91.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox91.TextChanged += new System.EventHandler(this.textBox91_TextChanged);
            // 
            // textBox90
            // 
            this.textBox90.BackColor = System.Drawing.SystemColors.Window;
            this.textBox90.Location = new System.Drawing.Point(160, 544);
            this.textBox90.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox90.Multiline = true;
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(20, 24);
            this.textBox90.TabIndex = 267;
            this.textBox90.Text = " ";
            this.textBox90.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(78, 544);
            this.textBox89.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox89.Multiline = true;
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(20, 24);
            this.textBox89.TabIndex = 266;
            this.textBox89.Text = "3.";
            this.textBox89.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(105, 544);
            this.textBox88.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox88.Multiline = true;
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(20, 24);
            this.textBox88.TabIndex = 265;
            this.textBox88.Text = " ";
            this.textBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(78, 346);
            this.textBox87.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox87.Multiline = true;
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(20, 24);
            this.textBox87.TabIndex = 264;
            this.textBox87.Text = " ";
            this.textBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(78, 279);
            this.textBox86.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox86.Multiline = true;
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(20, 24);
            this.textBox86.TabIndex = 263;
            this.textBox86.Text = " ";
            this.textBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(78, 244);
            this.textBox85.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox85.Multiline = true;
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(20, 24);
            this.textBox85.TabIndex = 262;
            this.textBox85.Text = " ";
            this.textBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(78, 175);
            this.textBox84.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox84.Multiline = true;
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(32, 24);
            this.textBox84.TabIndex = 261;
            this.textBox84.Text = "15.";
            this.textBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(489, 644);
            this.textBox82.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox82.Multiline = true;
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(20, 24);
            this.textBox82.TabIndex = 259;
            this.textBox82.Text = " ";
            this.textBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(434, 644);
            this.textBox81.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox81.Multiline = true;
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(20, 24);
            this.textBox81.TabIndex = 258;
            this.textBox81.Text = " ";
            this.textBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(407, 644);
            this.textBox80.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox80.Multiline = true;
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(20, 24);
            this.textBox80.TabIndex = 257;
            this.textBox80.Text = " ";
            this.textBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(462, 644);
            this.textBox76.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox76.Multiline = true;
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(20, 24);
            this.textBox76.TabIndex = 255;
            this.textBox76.Text = " ";
            this.textBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox75
            // 
            this.textBox75.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox75.Location = new System.Drawing.Point(462, 611);
            this.textBox75.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox75.Multiline = true;
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(20, 24);
            this.textBox75.TabIndex = 254;
            this.textBox75.Text = " ";
            this.textBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(462, 578);
            this.textBox67.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox67.Multiline = true;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(20, 24);
            this.textBox67.TabIndex = 253;
            this.textBox67.Text = " ";
            this.textBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(462, 544);
            this.textBox64.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox64.Multiline = true;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(20, 24);
            this.textBox64.TabIndex = 252;
            this.textBox64.Text = " ";
            this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(462, 515);
            this.textBox63.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox63.Multiline = true;
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(20, 24);
            this.textBox63.TabIndex = 251;
            this.textBox63.Text = " ";
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(462, 482);
            this.textBox62.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox62.Multiline = true;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(20, 24);
            this.textBox62.TabIndex = 250;
            this.textBox62.Text = " ";
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(462, 446);
            this.textBox61.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox61.Multiline = true;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(20, 24);
            this.textBox61.TabIndex = 249;
            this.textBox61.Text = " ";
            this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(462, 412);
            this.textBox60.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox60.Multiline = true;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(20, 24);
            this.textBox60.TabIndex = 248;
            this.textBox60.Text = " ";
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(462, 379);
            this.textBox59.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox59.Multiline = true;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(20, 24);
            this.textBox59.TabIndex = 247;
            this.textBox59.Text = " ";
            this.textBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(434, 379);
            this.textBox58.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox58.Multiline = true;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(20, 24);
            this.textBox58.TabIndex = 246;
            this.textBox58.Text = " ";
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(407, 379);
            this.textBox57.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox57.Multiline = true;
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(20, 24);
            this.textBox57.TabIndex = 245;
            this.textBox57.Text = " ";
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(379, 379);
            this.textBox56.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox56.Multiline = true;
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(20, 24);
            this.textBox56.TabIndex = 244;
            this.textBox56.Text = " ";
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(352, 379);
            this.textBox55.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox55.Multiline = true;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(20, 24);
            this.textBox55.TabIndex = 243;
            this.textBox55.Text = " ";
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox54
            // 
            this.textBox54.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox54.Location = new System.Drawing.Point(325, 379);
            this.textBox54.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox54.Multiline = true;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(20, 24);
            this.textBox54.TabIndex = 242;
            this.textBox54.Text = " ";
            this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox53
            // 
            this.textBox53.BackColor = System.Drawing.SystemColors.Window;
            this.textBox53.Location = new System.Drawing.Point(297, 379);
            this.textBox53.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox53.Multiline = true;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(20, 24);
            this.textBox53.TabIndex = 241;
            this.textBox53.Text = " ";
            this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox52
            // 
            this.textBox52.BackColor = System.Drawing.SystemColors.Window;
            this.textBox52.Location = new System.Drawing.Point(270, 379);
            this.textBox52.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox52.Multiline = true;
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(20, 24);
            this.textBox52.TabIndex = 240;
            this.textBox52.Text = " ";
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox51
            // 
            this.textBox51.BackColor = System.Drawing.SystemColors.Window;
            this.textBox51.Location = new System.Drawing.Point(242, 379);
            this.textBox51.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox51.Multiline = true;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(20, 24);
            this.textBox51.TabIndex = 239;
            this.textBox51.Text = " ";
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(179, 379);
            this.textBox50.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox50.Multiline = true;
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(28, 24);
            this.textBox50.TabIndex = 238;
            this.textBox50.Text = "11.";
            this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(215, 446);
            this.textBox49.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox49.Multiline = true;
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(20, 24);
            this.textBox49.TabIndex = 237;
            this.textBox49.Text = " ";
            this.textBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox48.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox48.Location = new System.Drawing.Point(215, 412);
            this.textBox48.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox48.Multiline = true;
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(20, 24);
            this.textBox48.TabIndex = 236;
            this.textBox48.Text = " ";
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.Window;
            this.textBox47.Location = new System.Drawing.Point(215, 379);
            this.textBox47.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox47.Multiline = true;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(20, 24);
            this.textBox47.TabIndex = 235;
            this.textBox47.Text = " ";
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(215, 346);
            this.textBox46.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox46.Multiline = true;
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(20, 24);
            this.textBox46.TabIndex = 234;
            this.textBox46.Text = " ";
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(215, 279);
            this.textBox45.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox45.Multiline = true;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(20, 24);
            this.textBox45.TabIndex = 233;
            this.textBox45.Text = " ";
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(215, 244);
            this.textBox44.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox44.Multiline = true;
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(20, 24);
            this.textBox44.TabIndex = 232;
            this.textBox44.Text = "4.";
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(133, 578);
            this.textBox43.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox43.Multiline = true;
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(20, 24);
            this.textBox43.TabIndex = 231;
            this.textBox43.Text = " ";
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(133, 544);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(20, 24);
            this.textBox11.TabIndex = 230;
            this.textBox11.Text = " ";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(133, 511);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(20, 24);
            this.textBox12.TabIndex = 229;
            this.textBox12.Text = " ";
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(133, 446);
            this.textBox13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(20, 24);
            this.textBox13.TabIndex = 228;
            this.textBox13.Text = " ";
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(133, 482);
            this.textBox14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(20, 24);
            this.textBox14.TabIndex = 227;
            this.textBox14.Text = " ";
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(133, 412);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(20, 24);
            this.textBox15.TabIndex = 226;
            this.textBox15.Text = " ";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(133, 346);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(20, 24);
            this.textBox16.TabIndex = 225;
            this.textBox16.Text = " ";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(133, 379);
            this.textBox17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(20, 24);
            this.textBox17.TabIndex = 224;
            this.textBox17.Text = " ";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(133, 279);
            this.textBox18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(20, 24);
            this.textBox18.TabIndex = 223;
            this.textBox18.Text = " ";
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox19.Location = new System.Drawing.Point(133, 244);
            this.textBox19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(30, 24);
            this.textBox19.TabIndex = 222;
            this.textBox19.Text = "10.";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox19.TextChanged += new System.EventHandler(this.textBox19_TextChanged);
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(242, 207);
            this.textBox20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(20, 24);
            this.textBox20.TabIndex = 221;
            this.textBox20.Text = " ";
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(366, 644);
            this.textBox21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(33, 24);
            this.textBox21.TabIndex = 102;
            this.textBox21.Text = "12.";
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(462, 346);
            this.textBox22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(20, 24);
            this.textBox22.TabIndex = 101;
            this.textBox22.Text = "1.";
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(297, 312);
            this.textBox23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(20, 24);
            this.textBox23.TabIndex = 100;
            this.textBox23.Text = " ";
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(270, 312);
            this.textBox24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox24.Multiline = true;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(20, 24);
            this.textBox24.TabIndex = 99;
            this.textBox24.Text = " ";
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(242, 312);
            this.textBox25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox25.Multiline = true;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(20, 24);
            this.textBox25.TabIndex = 98;
            this.textBox25.Text = " ";
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(215, 312);
            this.textBox26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox26.Multiline = true;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(20, 24);
            this.textBox26.TabIndex = 97;
            this.textBox26.Text = " ";
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(187, 312);
            this.textBox27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox27.Multiline = true;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(20, 24);
            this.textBox27.TabIndex = 96;
            this.textBox27.Text = " ";
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(160, 312);
            this.textBox28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox28.Multiline = true;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(20, 24);
            this.textBox28.TabIndex = 95;
            this.textBox28.Text = " ";
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(133, 312);
            this.textBox29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox29.Multiline = true;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(20, 24);
            this.textBox29.TabIndex = 94;
            this.textBox29.Text = " ";
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(105, 312);
            this.textBox30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox30.Multiline = true;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(20, 24);
            this.textBox30.TabIndex = 93;
            this.textBox30.Text = " ";
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(78, 312);
            this.textBox31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox31.Multiline = true;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(20, 24);
            this.textBox31.TabIndex = 92;
            this.textBox31.Text = " ";
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(50, 312);
            this.textBox32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox32.Multiline = true;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(20, 24);
            this.textBox32.TabIndex = 91;
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(23, 316);
            this.textBox33.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox33.Multiline = true;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(20, 24);
            this.textBox33.TabIndex = 90;
            this.textBox33.Text = "2.";
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(297, 207);
            this.textBox34.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox34.Multiline = true;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(20, 24);
            this.textBox34.TabIndex = 70;
            this.textBox34.Text = " ";
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(270, 207);
            this.textBox35.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox35.Multiline = true;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(20, 24);
            this.textBox35.TabIndex = 69;
            this.textBox35.Text = " ";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(215, 207);
            this.textBox36.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox36.Multiline = true;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(20, 24);
            this.textBox36.TabIndex = 67;
            this.textBox36.Text = " ";
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(187, 207);
            this.textBox37.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox37.Multiline = true;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(20, 24);
            this.textBox37.TabIndex = 66;
            this.textBox37.Text = " ";
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(160, 207);
            this.textBox38.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox38.Multiline = true;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(20, 24);
            this.textBox38.TabIndex = 65;
            this.textBox38.Text = " ";
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(133, 207);
            this.textBox39.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox39.Multiline = true;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(20, 24);
            this.textBox39.TabIndex = 64;
            this.textBox39.Text = " ";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox40.Location = new System.Drawing.Point(105, 207);
            this.textBox40.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox40.Multiline = true;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(20, 24);
            this.textBox40.TabIndex = 63;
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(78, 207);
            this.textBox41.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox41.Multiline = true;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(20, 24);
            this.textBox41.TabIndex = 62;
            this.textBox41.Text = " ";
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(50, 207);
            this.textBox42.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox42.Multiline = true;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(20, 24);
            this.textBox42.TabIndex = 61;
            this.textBox42.Text = "1.";
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // VarianteJuego1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1479, 1055);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ImagenCJ1);
            this.Controls.Add(this.NameCJ1);
            this.Controls.Add(this.PuntosJ2);
            this.Controls.Add(this.PuntosJ1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BotonFinalizar);
            this.Controls.Add(this.TexTiempoTG1);
            this.Controls.Add(this.TexTiempoPG1);
            this.Controls.Add(this.TextBoxTiempoTG1);
            this.Controls.Add(this.TextBoxTiempoPG1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "VarianteJuego1";
            this.Text = "VarianteJuego1";
            this.Load += new System.EventHandler(this.VarianteJuego1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ImagenCJ1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TabControl tabControl1;
        private TabPage tabPage1;
        private ListBox ListaDePistas1;
        private TabPage tabPage2;
        private ListBox listBox1;
        private Label TexTiempoTG1;
        private Label TexTiempoPG1;
        private TextBox TextBoxTiempoTG1;
        private TextBox TextBoxTiempoPG1;
        private Button BotonFinalizar;
        private TextBox PuntosJ2;
        private TextBox PuntosJ1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label5;
        private PictureBox ImagenCJ1;
        private TextBox NameCJ1;
        private GroupBox groupBox1;
        private TextBox textBox91;
        private TextBox textBox90;
        private TextBox textBox89;
        private TextBox textBox88;
        private TextBox textBox87;
        private TextBox textBox86;
        private TextBox textBox85;
        private TextBox textBox84;
        private TextBox textBox82;
        private TextBox textBox81;
        private TextBox textBox80;
        private TextBox textBox76;
        private TextBox textBox75;
        private TextBox textBox67;
        private TextBox textBox64;
        private TextBox textBox63;
        private TextBox textBox62;
        private TextBox textBox61;
        private TextBox textBox60;
        private TextBox textBox59;
        private TextBox textBox58;
        private TextBox textBox57;
        private TextBox textBox56;
        private TextBox textBox55;
        private TextBox textBox54;
        private TextBox textBox53;
        private TextBox textBox52;
        private TextBox textBox51;
        private TextBox textBox50;
        private TextBox textBox49;
        private TextBox textBox48;
        private TextBox textBox47;
        private TextBox textBox46;
        private TextBox textBox45;
        private TextBox textBox44;
        private TextBox textBox43;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private TextBox textBox21;
        private TextBox textBox22;
        private TextBox textBox23;
        private TextBox textBox24;
        private TextBox textBox25;
        private TextBox textBox26;
        private TextBox textBox27;
        private TextBox textBox28;
        private TextBox textBox29;
        private TextBox textBox30;
        private TextBox textBox31;
        private TextBox textBox32;
        private TextBox textBox33;
        private TextBox textBox34;
        private TextBox textBox35;
        private TextBox textBox36;
        private TextBox textBox37;
        private TextBox textBox38;
        private TextBox textBox39;
        private TextBox textBox40;
        private TextBox textBox41;
        private TextBox textBox42;
        private TextBox textBox116;
        private TextBox textBox115;
        private TextBox textBox114;
        private TextBox textBox113;
        private TextBox textBox112;
        private TextBox textBox111;
        private TextBox textBox110;
        private TextBox textBox109;
        private TextBox textBox108;
        private TextBox textBox107;
        private TextBox textBox106;
        private TextBox textBox92;
        private TextBox textBox122;
        private TextBox textBox121;
        private TextBox textBox120;
        private TextBox textBox119;
        private TextBox textBox118;
        private TextBox textBox66;
        private TextBox textBox65;
        private TextBox textBox10;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox128;
        private TextBox textBox126;
        private TextBox textBox125;
        private TextBox textBox124;
        private TextBox textBox79;
        private TextBox textBox78;
        private TextBox textBox77;
        private TextBox textBox172;
        private TextBox textBox173;
        private TextBox textBox174;
        private TextBox textBox171;
        private TextBox textBox162;
        private TextBox textBox163;
        private TextBox textBox164;
        private TextBox textBox165;
        private TextBox textBox166;
        private TextBox textBox167;
        private TextBox textBox168;
        private TextBox textBox169;
        private TextBox textBox170;
        private TextBox textBox153;
        private TextBox textBox154;
        private TextBox textBox155;
        private TextBox textBox156;
        private TextBox textBox157;
        private TextBox textBox158;
        private TextBox textBox159;
        private TextBox textBox160;
        private TextBox textBox161;
        private TextBox textBox141;
        private TextBox textBox142;
        private TextBox textBox144;
        private TextBox textBox147;
        private TextBox textBox148;
        private TextBox textBox149;
        private TextBox textBox150;
        private TextBox textBox151;
        private TextBox textBox152;
        private TextBox textBox139;
        private TextBox textBox137;
        private TextBox textBox136;
        private TextBox textBox138;
        private TextBox textBox140;
        private TextBox textBox143;
        private TextBox textBox145;
        private TextBox textBox146;
        private TextBox textBox101;
        private TextBox textBox117;
        private TextBox textBox123;
        private TextBox textBox127;
        private TextBox textBox129;
        private TextBox textBox130;
        private TextBox textBox131;
        private TextBox textBox132;
        private TextBox textBox133;
        private TextBox textBox134;
        private TextBox textBox135;
        private TextBox textBox68;
        private TextBox textBox96;
        private TextBox textBox97;
        private TextBox textBox98;
        private TextBox textBox99;
        private TextBox textBox100;
        private TextBox textBox102;
        private TextBox textBox103;
        private TextBox textBox104;
        private TextBox textBox105;
        private TextBox textBox69;
        private TextBox textBox70;
        private TextBox textBox71;
        private TextBox textBox72;
        private TextBox textBox73;
        private TextBox textBox74;
        private TextBox textBox83;
        private TextBox textBox93;
        private TextBox textBox94;
        private TextBox textBox95;
        private TextBox textBox175;
        private TextBox textBox199;
        private TextBox textBox200;
        private TextBox textBox201;
        private TextBox textBox202;
        private TextBox textBox203;
        private TextBox textBox204;
        private TextBox textBox205;
        private TextBox textBox206;
        private TextBox textBox207;
        private TextBox textBox208;
        private TextBox textBox209;
        private TextBox textBox188;
        private TextBox textBox189;
        private TextBox textBox190;
        private TextBox textBox191;
        private TextBox textBox192;
        private TextBox textBox193;
        private TextBox textBox194;
        private TextBox textBox195;
        private TextBox textBox196;
        private TextBox textBox197;
        private TextBox textBox198;
        private TextBox textBox176;
        private TextBox textBox177;
        private TextBox textBox178;
        private TextBox textBox179;
        private TextBox textBox180;
        private TextBox textBox181;
        private TextBox textBox182;
        private TextBox textBox183;
        private TextBox textBox184;
        private TextBox textBox185;
        private TextBox textBox186;
        private TextBox textBox187;
        private TextBox textBox210;
        private TextBox textBox211;
        private TextBox textBox212;
        private TextBox textBox213;
        private TextBox textBox214;
        private TextBox textBox215;
        private TextBox textBox216;
        private TextBox textBox217;
        private TextBox textBox218;
        private TextBox textBox269;
        private TextBox textBox260;
        private TextBox textBox261;
        private TextBox textBox262;
        private TextBox textBox263;
        private TextBox textBox264;
        private TextBox textBox265;
        private TextBox textBox266;
        private TextBox textBox267;
        private TextBox textBox268;
        private TextBox textBox252;
        private TextBox textBox253;
        private TextBox textBox256;
        private TextBox textBox257;
        private TextBox textBox258;
        private TextBox textBox259;
        private TextBox textBox239;
        private TextBox textBox248;
        private TextBox textBox249;
        private TextBox textBox250;
        private TextBox textBox251;
        private TextBox textBox254;
        private TextBox textBox255;
        private TextBox textBox241;
        private TextBox textBox242;
        private TextBox textBox243;
        private TextBox textBox244;
        private TextBox textBox245;
        private TextBox textBox246;
        private TextBox textBox247;
        private TextBox textBox240;
        private TextBox textBox228;
        private TextBox textBox229;
        private TextBox textBox230;
        private TextBox textBox231;
        private TextBox textBox232;
        private TextBox textBox233;
        private TextBox textBox234;
        private TextBox textBox235;
        private TextBox textBox236;
        private TextBox textBox237;
        private TextBox textBox238;
        private TextBox textBox227;
        private TextBox textBox226;
        private TextBox textBox219;
        private TextBox textBox220;
        private TextBox textBox221;
        private TextBox textBox222;
        private TextBox textBox223;
        private TextBox textBox224;
        private TextBox textBox225;
        private TextBox textBox281;
        private TextBox textBox274;
        private TextBox textBox275;
        private TextBox textBox276;
        private TextBox textBox277;
        private TextBox textBox278;
        private TextBox textBox279;
        private TextBox textBox280;
        private TextBox textBox283;
        private TextBox textBox284;
        private TextBox textBox285;
        private TextBox textBox286;
        private TextBox textBox282;
        private System.Windows.Forms.Timer timer1;
    }
}