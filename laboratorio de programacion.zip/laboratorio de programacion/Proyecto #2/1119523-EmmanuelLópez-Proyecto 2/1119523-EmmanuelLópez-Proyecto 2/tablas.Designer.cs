﻿namespace _1119523_EmmanuelLópez_Proyecto_2
{
    partial class tablas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Historial = new System.Windows.Forms.ListBox();
            this.Cerrar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Historial);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(830, 397);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Historial de Partidas";
            // 
            // Historial
            // 
            this.Historial.FormattingEnabled = true;
            this.Historial.ItemHeight = 20;
            this.Historial.Location = new System.Drawing.Point(6, 22);
            this.Historial.Name = "Historial";
            this.Historial.Size = new System.Drawing.Size(818, 364);
            this.Historial.TabIndex = 0;
            this.Historial.SelectedIndexChanged += new System.EventHandler(this.Historial_SelectedIndexChanged);
            // 
            // Cerrar
            // 
            this.Cerrar.Location = new System.Drawing.Point(235, 430);
            this.Cerrar.Name = "Cerrar";
            this.Cerrar.Size = new System.Drawing.Size(384, 35);
            this.Cerrar.TabIndex = 20;
            this.Cerrar.Text = "salir";
            this.Cerrar.UseVisualStyleBackColor = true;
            this.Cerrar.Click += new System.EventHandler(this.Cerrar_Click);
            // 
            // tablas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 504);
            this.Controls.Add(this.Cerrar);
            this.Controls.Add(this.groupBox1);
            this.Name = "tablas";
            this.Text = "tablas";
            this.Load += new System.EventHandler(this.tablas_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private ListBox Historial;
        private Button Cerrar;
    }
}