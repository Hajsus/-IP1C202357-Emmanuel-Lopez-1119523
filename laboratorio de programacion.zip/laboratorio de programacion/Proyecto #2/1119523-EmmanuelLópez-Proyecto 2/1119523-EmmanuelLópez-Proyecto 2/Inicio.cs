namespace _1119523_EmmanuelLópez_Proyecto_2
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }
        private bool ajustesCerrados = false;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TituloDelGame_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        private void BotonSalir_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }
       

        private void tablas_Click(object sender, EventArgs e)
        {
           tablas _Historial = new tablas();
            _Historial.Show();
        }

        private void configuraciones_Click(object sender, EventArgs e)
        {
            Configuracion _configuracion = new Configuracion ();
            _configuracion.ShowDialog(); // Cambia Show() por ShowDialog()
            ajustesCerrados = true;
        }

        private void juego_Click(object sender, EventArgs e)
        {
            if (ajustesCerrados)
            {
                VarianteJuego1 juego1 = new VarianteJuego1();
                juego1.Show();
            }
            else
            {
                MessageBox.Show("Por favor, configure los ajustes antes de jugar.");
            }
        }

        private void Inicio_Load(object sender, EventArgs e)
        {

        }
    }
}
