﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1119523_EmmanuelLópez_Proyecto_2
{
    public partial class VarianteJuego1 : Form
    {
        public readonly Variables classVariables;
        private bool BotonFinalizarPresionado;
        private int _tiempoPG1, _tiempoTG1;
        private int _PuntosJ1 = 0;
        private int _PuntosJ2 = 0;
        public VarianteJuego1(Variables _variables)
        {
            InitializeComponent();
            classVariables = _variables;
            _tiempoPG1 = classVariables.tiempoP;
            _tiempoTG1 = classVariables.tiempoT;
            TextBoxTiempoPG1.Text = _tiempoPG1.ToString();
            TextBoxTiempoTG1.Text = _tiempoTG1.ToString();
            ImagenCJ1.Image = classVariables.imagenJ1;

        }
        public VarianteJuego1()
        {
            InitializeComponent();
        }

        private void TexTiempoTG1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ImagenCJ1_Click(object sender, EventArgs e)
        {
            ImagenCJ1.Image = classVariables.imagenJ1;
        }

        private void NameCJ1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox91_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox116_TextChanged(object sender, EventArgs e)
        {

        }

        private void VarianteJuego1_Load(object sender, EventArgs e)
        {

        }

        private void CajaJuego1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox273_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void BotonFinalizar_Click(object sender, EventArgs e)
        {
            if (!BotonFinalizarPresionado)
            {
                BotonFinalizarPresionado = true;
            }

            if (!BotonFinalizarPresionado)
            {
                BotonFinalizarPresionado = true;
                _tiempoTG1 = 0;
            }
            if (ImagenCJ1.Image == classVariables.imagenJ1)
            {
                _PuntosJ1++;
            }
            else if (ImagenCJ1.Image == classVariables.imagenJ2)
            {
                _PuntosJ2++;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            _tiempoPG1--; 
            TextBoxTiempoPG1.Text = _tiempoPG1.ToString();
            if (_tiempoPG1 == 0)
            {
                BotonFinalizar.Enabled = false;
                timer1.Stop();

                MessageBox.Show("Se acabó el tiempo. ¡Fin de la partida!");
                _tiempoTG1--; // Restar 1 segundo al tiempo total
                TextBoxTiempoTG1.Text = _tiempoTG1.ToString();
                if (_tiempoTG1 == 0)
                {
                    _tiempoTG1 = classVariables.tiempoT;
                    // Reemplazar la imagenJ1 por imagenJ2 al terminar el tiempo total
                    Image tempImagen = classVariables.imagenJ1;
                    classVariables.imagenJ1 = classVariables.imagenJ2;
                    classVariables.imagenJ2 = tempImagen;
                    ImagenCJ1.Image = classVariables.imagenJ1;

                    // Reemplazar el nombreJ1 por nombreJ2 al terminar el tiempo total
                    string tempNombre = classVariables.nombreJ1;
                    classVariables.nombreJ1 = classVariables.nombreJ2;
                    classVariables.nombreJ2 = tempNombre;
                    NameCJ1.Text = classVariables.nombreJ1;
                }
            }
        }

        private void VarianteJuego1_Load_1(object sender, EventArgs e)
        {

        }

        private void textBox280_TetChanged(object sender, EventArgs e)
        {

        }
    }
}
