﻿//Vector
int[] vector = new int[10];

int[] _otro;
_otro = new int[3];

int[] valores = new int[3] { 1, 2, 20};
    
//Matrix

int[,] matriz = new int[2, 3];

for (int i = 0; i < valores.Length; i++)
{
	if (valores[i] <= 2 && valores[i] >= 0)
	{
		Console.WriteLine(valores[i]);
	}
    if (valores[i] ==2)
	{

	}
}

