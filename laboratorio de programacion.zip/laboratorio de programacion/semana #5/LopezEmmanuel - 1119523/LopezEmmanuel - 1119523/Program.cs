﻿

//calculadora

/*
 
Analisis
- Operadores (suma, resta, division, multiplicacion)
- Ingresados por el usuario
- Mostrarlos y almacenarlos
    - 5 valores numericos a almacenar + el resultado
- Operarlos
- Mostrar resultados
- preguntarle al usuario si quiere operar otros numeros
- Definir cantidad maxima de numeros de ingresar y operar
- Cuantas operaciones quiere hacer
    -  1 operacion de cada tipo por ecuacion
        - Ej: 4x5+15/20-10
- Borrar
- Manejo de errores
- Manejo de suma sobre el ultimo valor resultante

*/

//tipos de datos
double _numeroA, _numeroB, _numeroC, _numeroD, _numeroE, _resultado;

Console.WriteLine("CALCULADORA");
Console.WriteLine("La calculadora resuelve operaciones del siquiente tipo:"  + 
    "numeroUno x numeroDos + numeroTres / numeroCuatro - numeroCinco" + 
    "Usted debara de ingresar los numeros para operar");

//Obtener valores

Console.WriteLine("Ingrese el primer numero");
string _aux = Console.ReadLine();

if(_aux != "") 
{
    _numeroA = double.Parse(_aux);
}
else
{
    _numeroA = 0.0;
}
//_numeroA = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el segundo numero");
_aux = Console.ReadLine();

if (_aux != "")
{
    _numeroB = double.Parse(_aux);
}
else
{
    _numeroB = 0.0;
}
//_numeroB = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el tercer numero");
 _aux = Console.ReadLine();


if (_aux != "")
{
    _numeroC= double.Parse(_aux);
}
else
{
    _numeroC = 0.0;
}
//_numeroC = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el cuarto numero");
_aux = Console.ReadLine();

if (_aux != "")
{
    _numeroD = double.Parse(_aux);
}
else
{
    _numeroD = 0.0;
}
//_numeroD = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el quinto numero");
_aux = Console.ReadLine();

if (_aux != "")
{
    _numeroE = double.Parse(_aux);
}
else
{
    _numeroE = 0.0;
}
//_numeroE = Convert.ToDouble(Console.ReadLine());

// Operar (4x5+15)/(20-10)

_resultado = (((_numeroA * _numeroB) + _numeroC)/ (_numeroD - _numeroE));

Console.WriteLine("El resultado de la operacion es: " + _resultado);
Console.WriteLine("Quiere autosumar su resultado?");
string sAutosumar = Console.ReadLine().ToLower();

if(sAutosumar == "si")
{
    for (int i = 0; i < 10; i++)
    {
        _resultado = _resultado + _resultado;
    }
    Console.WriteLine("El resultado es: " + _resultado);
}
else
{
    Console.WriteLine("Si desea finalizar ingrese una tecla");
}

Console.ReadLine();



