namespace _1119523_EmmanuelLopez_semana10
{
    public partial class Form1 : Form
    {
        Automovil automovil = new Automovil();

        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los datos de los controles
            modelo = int.Parse(textBox1.Text);
            precio = double.Parse(textBox2.Text);
            marca = textBox3.Text;
            tipoCambioDolar = double.Parse(textBox4.Text);

            // Mostrar los datos en el ListBox
            listBox1.Items.Clear();
            listBox1.Items.Add("Modelo: " + modelo);
            listBox1.Items.Add("Precio: " + precio);
            listBox1.Items.Add("Marca: " + marca);
            listBox1.Items.Add("Tipo de cambio: " + tipoCambioDolar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Obtener el descuento
            descuentoAplicado = double.Parse(textBox5.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Actualizar los datos en el ListBox con el descuento aplicado
            listBox1.Items.Clear();
            listBox1.Items.Add("Modelo: " + modelo);
            listBox1.Items.Add("Precio: " + (precio - descuentoAplicado));
            listBox1.Items.Add("Marca: " + marca);
            listBox1.Items.Add("Tipo de cambio: " + tipoCambioDolar);
        }
    }
}