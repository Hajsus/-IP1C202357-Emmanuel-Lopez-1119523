﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Bienvenidos al Restaurante KrustyBurger");

//Crear menu de un restaurante para poder despachar pedidos
// Items: Hamburguesas, Aguas, Papas, Helado, Pizza, Pastas y Postres
//Mostrar menu
//Ordenar
//Pago

bool _continuar = false;
int _opcionMenu = 0;
int _Menu1 = 0, _Menu2 = 0, _Menu3 = 0, _Menu4 = 0, _Menu5 = 0, _Menu6 = 0, _Menu7 = 0;

Console.WriteLine("El menu es: ");
Console.WriteLine("1. Hamburguesa de Lomito");
Console.WriteLine("2. Pasta al Pesto");
Console.WriteLine("3. Postre - Pastel de Triple Chocolate");
Console.WriteLine("4. Pizza de Pepperoni");
Console.WriteLine("5. Helado - Galleta");
Console.WriteLine("6. Papas Fritas con Queso");
Console.WriteLine("7. Bebidas");

Console.WriteLine("Seleccione el item del menu que desea ordenar");
try
{
    int _PrecioMenu1 = 40, _PrecioMenu2 = 35, _PrecioMenu3 = 25, _PrecioMenu4 = 40, _PrecioMenu5 = 15, _PrecioMenu6 = 30, _PrecioMenu7 = 10;

    do
    {
        _opcionMenu = int.Parse(Console.ReadLine());

        switch (_opcionMenu)
        {
            case 1:
                _Menu1++;
                break;
            case 2:
                _Menu2++;
                break;
            case 3:
                _Menu3++;
                break;
            case 4:
                _Menu4++;
                break;
            case 5:
                _Menu5++;
                break;
            case 6:
                _Menu6++;
                break;
            case 7:
                _Menu7++;
                break;

            default:
                Console.WriteLine("Ingrese un numero valido");
                break;

        }
        Console.WriteLine("Desea continuar? si/no");
        string _respuesta = Console.ReadLine().ToLower();

        if (_respuesta == "si")
        {
            _continuar = true;
            Console.WriteLine("Ingrese el siguiente item del menu que desea ordenar");

        }
        else
        {
            int total = 0;
            Console.WriteLine("El costo es:");
            if (_Menu1 > 0)
            {
                total += _Menu1 * _PrecioMenu1;
                Console.WriteLine("Hamburguesa de Lomito: " + _Menu1 * _PrecioMenu1);
            }
            if (_Menu2 > 0)
            {
                total += _Menu2 * _PrecioMenu2;
                Console.WriteLine("Pasta al Pesto: " + _Menu2 * _PrecioMenu2);
            }
             if (_Menu3 > 0)
            {
                total += _Menu3 * _PrecioMenu3;
                Console.WriteLine("Postre - Pastel de Triple Chocolate: " + _Menu3 * _PrecioMenu3);
            }
            if (_Menu4 > 0)
            {
                total += _Menu4 * _PrecioMenu4;
                Console.WriteLine("Pizza de Pepperoni: " + _Menu4 * _PrecioMenu4);
            }
            if (_Menu5 > 0)
            {
                total += _Menu5 * _PrecioMenu5;
                Console.WriteLine("Helado - Galleta: " + _Menu5 * _PrecioMenu5);
            }
            if (_Menu6 > 0)
            {
                total += _Menu6 * _PrecioMenu6;
                Console.WriteLine("Papas Fritas con Queso: " + _Menu6 * _PrecioMenu6);
            }
            if(_Menu7 > 0)
            {
                total += _Menu7 * _PrecioMenu7;
                Console.WriteLine("Bebidas: " + _Menu7 * _PrecioMenu7);
            }
            Console.WriteLine("Total a pagar: " + total);

                _continuar = false;
                //int Total = _PrecioMenu1 + _PrecioMenu2 + _PrecioMenu3 + _PrecioMenu4 + _PrecioMenu5 + _PrecioMenu6 + _PrecioMenu7;

                //Console.WriteLine(Total);
        
        }
    } while (_continuar == true);
}
catch (Exception)
{
    Console.WriteLine("Ha existido un error. Vuelva a ejecutar el programa");

};

Console.ReadLine(); 



    